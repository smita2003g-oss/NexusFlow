## Summary
<!-- What user-visible change and why? Link the issue. -->

## Evidence
<!-- Include actual test outputs, explain operational impact and provide benchmarks if relevant. -->

## Checklist
- [ ] Change has a linked GitHub issue and clear acceptance criteria.
- [ ] Code was reviewed by a human contributor.
- [ ] Tests cover success, error, retry, crash and race behavior as applicable.
- [ ] Ran `cargo fmt --all -- --check`.
- [ ] Ran `cargo clippy --workspace --all-targets -- -D warnings`.
- [ ] Ran `cargo test --workspace -- --test-threads=1` with PostgreSQL.
- [ ] Updated docs / design decisions and CHANGELOG as needed.
- [ ] Described AI assistance honestly (none / low / moderate / high; files/lines).
- [ ] No invented timestamps, inflated LOC, fabricated team identities, or synthetic PR history.
