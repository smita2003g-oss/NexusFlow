# NexusFlow — Distributed Workflow Automation Engine (Rust)

**Status:** early-stage, AI-generated engineering foundation; **not production-ready** and **not eligible for a human-majority code-history submission in its present form**. See [AI/provenance disclosure](AI_DISCLOSURE.md) and [verification report](VERIFICATION.md).

NexusFlow is a PostgreSQL-backed, horizontally scalable workflow executor. A workflow is a directed acyclic graph (DAG) of tasks. Independent tasks can execute concurrently across multiple Rust worker processes. The API creates workflows/runs, and each worker claims ready work using PostgreSQL row locks and expiring leases.

## Features implemented

- Rust Cargo workspace: domain validation, PostgreSQL persistence, REST API and asynchronous worker.
- Validated DAG: duplicate ID, unknown edge, self-dependency and cycle detection; 256-task/32-edge limits.
- Transactional run creation and request idempotency (`Idempotency-Key` scoped to workflow).
- Durable `pending → running → succeeded/failed/retry_wait/canceled` task state transitions.
- `FOR UPDATE SKIP LOCKED` claims; per-task leases, worker heartbeats, attempt-number fencing.
- Worker crash/lease reclaim and exhaustion reaper; bounded exponential retry delays.
- Concurrency-safe workflow completion by locking the parent run before final-task updates.
- Built-in actions: `echo`, `input`, `collect`, `sleep`, `fail`, `http` (HTTPS and explicit hostname allowlist by default).
- JSON REST API protected by bearer token; health/readiness endpoints.
- Unit tests, PostgreSQL integration tests, example DAGs, GitHub Actions, Docker Compose.

**Delivery semantics:** at least once, NOT exactly once. Lost workers can cause repeated side effects; a receiver must honor the propagated HTTP `Idempotency-Key`, or tasks must implement safe deduplication. A request may have reached its destination even if NexusFlow reports timeout or lease loss.

## Architecture

```text
     REST client
         |
    bearer token
         v
  nexusflow-server  ---->  PostgreSQL  <----  nexusflow-worker A
   POST /workflows          |  ^             nexusflow-worker B
   POST /runs               |  |             nexusflow-worker N
   GET /runs                |  |
   POST /cancel             |  +--- leases/heartbeats/fenced writes
                            +------ DAG tasks/dependency edges
```

Only the API should be reachable by clients; workers connect directly to PostgreSQL. For a production deployment, restrict workers' network egress and database permissions, add TLS, use a proper identity/authorization service, and implement further operational hardening.

## Quickstart: Docker Compose

Requirements: Docker Engine with Compose v2. No local Rust installation necessary.

```bash
# Inspect docker-compose.yml first. The credentials are development-only.
docker compose up --build -d
curl http://localhost:8080/healthz
curl http://localhost:8080/readyz
```

The Compose API token is `local-development-token-change-me-123456` and must **never** be used outside a local-only environment. It is intentionally explicit so you can reproduce the examples; change it before sharing any deployment.

```bash
export TOKEN=local-development-token-change-me-123456
export BASE=http://localhost:8080

# Create a workflow
curl -sS -X POST "$BASE/v1/workflows" \
  -H "Authorization: Bearer $TOKEN" \
  -H 'Content-Type: application/json' \
  --data-binary @examples/hello-dag.json
```

Copy `id` from the workflow response:

```bash
export WORKFLOW_ID=<copy-workflow-uuid>
curl -sS -X POST "$BASE/v1/workflows/$WORKFLOW_ID/runs" \
  -H "Authorization: Bearer $TOKEN" \
  -H 'Idempotency-Key: example-run-001' \
  -H 'Content-Type: application/json' \
  -d '{"input":{"name":"Ada"}}'

export RUN_ID=<copy-run-uuid>
curl -sS -H "Authorization: Bearer $TOKEN" "$BASE/v1/runs/$RUN_ID"
```

Once `status` becomes `succeeded`, inspect `tasks[].result`. Repeating the same run-start request with the same idempotency key returns the original run instead of creating another. To scale out workers locally:

```bash
docker compose up -d --scale worker=3
```

Run the end-to-end demonstration after startup: `python3 scripts/demo.py --token "$TOKEN"`. To stop and remove dev containers: `docker compose down`. To also **delete dev database data**: `docker compose down -v`.

## Local Rust development

Install stable Rust (>=1.85) with `rustfmt` and `clippy`, and PostgreSQL 16/17+. Use a **dedicated test database** because integration tests inspect/claim globally ready tasks.

```bash
docker compose up -d db
cp .env.example .env
# Edit secrets and DATABASE_URL; export .env into your shell before starting.
export DATABASE_URL=postgres://nexusflow:nexusflow@localhost:5432/nexusflow
export NEXUSFLOW_API_TOKEN=change-this-secret-to-at-least-32-bytes

cargo run -p nexusflow-server
# Other terminal, same DATABASE_URL:
cargo run -p nexusflow-worker

cargo fmt --all                 # Apply rustfmt once on a Rust machine
cargo fmt --all -- --check     # Then verify formatting
cargo clippy --workspace --all-targets -- -D warnings
# With PostgreSQL available, test sequentially (shared queue):
cargo test --workspace -- --test-threads=1
```

The first Cargo build creates `Cargo.lock`. Commit and maintain it for repeatable application releases. This archive was prepared in an environment without Rust/Cargo and therefore **has no generated Cargo.lock, no successful local compilation, and no locally executed Rust test results**. CI is configured to run the checks once installed in a real GitHub repository.

## HTTP API

All `/v1/*` requests require `Authorization: Bearer <NEXUSFLOW_API_TOKEN>`.

| Method | Path | Body/result |
| --- | --- | --- |
| `POST` | `/v1/workflows` | Workflow JSON; responds `201` with definition and ID |
| `GET` | `/v1/workflows?limit=50` | Lists latest definitions (max 100) |
| `GET` | `/v1/workflows/{id}` | Saved definition |
| `POST` | `/v1/workflows/{id}/runs` | `{ "input": { ... } }`, optional `Idempotency-Key` header |
| `GET` | `/v1/runs/{id}` | Run status and task status/results |
| `POST` | `/v1/runs/{id}/cancel` | Cancel nonterminal workflow run |
| `GET` | `/healthz` | Process liveness (public) |
| `GET` | `/readyz` | Database connectivity (public) |

An HTTP task must target a hostname explicitly listed in `NEXUSFLOW_ALLOWED_HTTP_HOSTS`. The demo Compose worker permits `httpbin.org`. The host allowlist alone does not prevent DNS rebinding or a hostname resolving to an internal IP, so apply egress restrictions. An HTTP task can send the workflow input as JSON via `body_from_input: true` or send a literal `body`. HTTP 5xx, 408 and 429 retry; other HTTP 4xx do not. HTTP redirects are disabled. The response body is capped at 1 MiB; JSON is decoded, other payloads become strings.

## Configuration

| Variable | Default | Meaning |
| --- | --- | --- |
| `DATABASE_URL` | required | PostgreSQL DSN |
| `NEXUSFLOW_API_TOKEN` | required for API | Bearer token; minimum 16 bytes |
| `NEXUSFLOW_BIND` | `0.0.0.0:8080` | HTTP server bind address |
| `NEXUSFLOW_CONCURRENCY` | `8` | In-flight tasks per worker process, max 64 |
| `NEXUSFLOW_LEASE_SECONDS` | `60` | Expiring lease, min 10 seconds |
| `NEXUSFLOW_POLL_MS` | `250` | Poll time when queue empty |
| `NEXUSFLOW_ALLOW_HTTP` | `false` | Allow unencrypted HTTP in worker (development only) |
| `NEXUSFLOW_ALLOWED_HTTP_HOSTS` | empty (deny all) | Comma-separated exact hostnames permitted for outbound HTTP actions |
| `RUST_LOG` | `info` | Structured logging filter |

## Repository

```text
apps/nexusflow-server/        REST control plane (Axum)
apps/nexusflow-worker/        Async actions, leases & retries (Tokio)
crates/nexusflow-core/        Types, validation, pure scheduling rules
crates/nexusflow-store/       SQLx/Postgres persistence + DB tests
migrations/                  SQL schema
examples/                    Runnable workflow definitions
docs/                        Architecture, safety notes and ADRs
.github/                     CI, issue templates, PR template
scripts/                     Independent static checks, LOC audit and Python API demo
```

## Important limitations

- **Not production hardened**: a shared bearer token, no tenants/RBAC, no audit trail, no observability metrics, no task result retention policy, no pagination of run history, no online DB migration policy, and no performance benchmarks.
- HTTP actions can reach internal endpoints through allowlisted hostnames resolving to private addresses unless the **deployment enforces outbound egress controls**. Do not expose to untrusted users or production networks without strict network policy/allowlists and additional URL validation.
- No workflow version upgrades, cron schedules, event triggers, pause/resume, dynamic fan-out, human approvals or workflow definition UI yet.
- Canceled HTTP requests already accepted by an external service cannot be rolled back. Task outputs are limited only for HTTP; `input`/`echo` payloads need size controls before production.
- Retrying timed-out/nonresponding remote actions can duplicate side effects. Idempotency relies on target system compliance.
- A damaged database or prolonged DB outage can delay lease completion/recovery. PostgreSQL is a single control-plane dependency; configure backups and HA independently.
- Local compilation/tests could not run in the authoring environment (no Rust compiler or Cargo). See [VERIFICATION.md](VERIFICATION.md).

## Contribution and ownership

The initial repository is **substantially AI-generated**, so it does **not** meet any requirement for human-majority code, years of genuine team activity, or existing GitHub PR history. It is shared as a starter, not represented as an existing human-created company asset. Review [AI_DISCLOSURE.md](AI_DISCLOSURE.md), [CONTRIBUTING.md](CONTRIBUTING.md), and [docs/roadmap.md](docs/roadmap.md).

License: [MIT](LICENSE). Do not treat this label alone as proof of exclusive rights or that a third party has never seen equivalent code. Review with legal counsel before making provenance-sensitive submissions.
