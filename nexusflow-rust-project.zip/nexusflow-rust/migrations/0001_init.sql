-- Durable workflow definitions, runs and fenced task leases.
CREATE TABLE workflow_definitions (
    id          UUID PRIMARY KEY,
    name        TEXT NOT NULL,
    definition  JSONB NOT NULL,
    created_at  TIMESTAMPTZ NOT NULL DEFAULT now()
);

CREATE TABLE workflow_runs (
    id               UUID PRIMARY KEY,
    workflow_id      UUID NOT NULL REFERENCES workflow_definitions(id),
    status           TEXT NOT NULL DEFAULT 'running'
                     CHECK (status IN ('running', 'succeeded', 'failed', 'canceled')),
    input            JSONB NOT NULL DEFAULT '{}'::jsonb,
    idempotency_key  TEXT,
    created_at       TIMESTAMPTZ NOT NULL DEFAULT now(),
    updated_at       TIMESTAMPTZ NOT NULL DEFAULT now(),
    completed_at     TIMESTAMPTZ,
    UNIQUE (workflow_id, idempotency_key),
    CHECK (idempotency_key IS NULL OR length(idempotency_key) BETWEEN 1 AND 200)
);

CREATE TABLE task_runs (
    id               UUID PRIMARY KEY,
    run_id           UUID NOT NULL REFERENCES workflow_runs(id) ON DELETE CASCADE,
    node_id          TEXT NOT NULL,
    status           TEXT NOT NULL DEFAULT 'pending'
                     CHECK (status IN ('pending', 'running', 'retry_wait', 'succeeded', 'failed', 'canceled')),
    attempts         INTEGER NOT NULL DEFAULT 0 CHECK (attempts >= 0),
    max_attempts     INTEGER NOT NULL CHECK (max_attempts BETWEEN 1 AND 20),
    next_attempt_at  TIMESTAMPTZ NOT NULL DEFAULT now(),
    lease_owner      TEXT,
    lease_expires_at TIMESTAMPTZ,
    result           JSONB,
    error            TEXT,
    created_at       TIMESTAMPTZ NOT NULL DEFAULT now(),
    updated_at       TIMESTAMPTZ NOT NULL DEFAULT now(),
    started_at       TIMESTAMPTZ,
    finished_at      TIMESTAMPTZ,
    UNIQUE (run_id, node_id)
);

CREATE TABLE task_dependencies (
    task_id             UUID NOT NULL REFERENCES task_runs(id) ON DELETE CASCADE,
    depends_on_node_id  TEXT NOT NULL,
    PRIMARY KEY (task_id, depends_on_node_id)
);

CREATE INDEX task_runs_due_idx
    ON task_runs(next_attempt_at, created_at)
    WHERE status IN ('pending', 'retry_wait');
CREATE INDEX task_runs_lease_idx
    ON task_runs(lease_expires_at)
    WHERE status = 'running';
CREATE INDEX task_runs_run_status_idx ON task_runs(run_id, status);
CREATE INDEX task_dependencies_task_idx ON task_dependencies(task_id);
CREATE INDEX workflow_runs_workflow_created_idx ON workflow_runs(workflow_id, created_at DESC);
