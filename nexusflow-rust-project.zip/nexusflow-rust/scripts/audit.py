#!/usr/bin/env python3
"""Offline structural and provenance audit (not a substitute for cargo test)."""

from __future__ import annotations

import argparse
import hashlib
import json
from pathlib import Path
import subprocess
import sys
import tomllib

ROOT = Path(__file__).resolve().parents[1]
IGNORED_PARTS = {".git", "target", ".idea", ".vscode", "__pycache__"}
REQUIRED_FILES = [
    "Cargo.toml",
    "LICENSE",
    "README.md",
    "AI_DISCLOSURE.md",
    "VERIFICATION.md",
    "CONTRIBUTING.md",
    "SECURITY.md",
    "Dockerfile",
    "scripts/audit.py",
    "scripts/demo.py",
    "scripts/verify.sh",
    ".gitattributes",
    "docker-compose.yml",
    "migrations/0001_init.sql",
    ".github/workflows/ci.yml",
    ".github/PULL_REQUEST_TEMPLATE.md",
    ".github/ISSUE_TEMPLATE/bug.yml",
    ".github/ISSUE_TEMPLATE/feature.yml",
    "docs/architecture.md",
    "docs/roadmap.md",
    "docs/adr/0001-postgres-as-queue.md",
    "docs/adr/0002-at-least-once-delivery.md",
    "docs/adr/0003-expiring-leases.md",
]


def error_if(condition: bool, message: str, errors: list[str]) -> None:
    if condition:
        errors.append(message)


def yaml_check(paths: list[Path], errors: list[str]) -> str:
    # Optional on local machines; PyYAML is not required by CI's Python install.
    try:
        import yaml  # type: ignore[import-not-found]
    except ImportError:
        return "unavailable (PyYAML not installed)"
    for path in paths:
        try:
            yaml.safe_load(path.read_text(encoding="utf-8"))
        except Exception as exc:  # noqa: BLE001
            errors.append(f"cannot parse YAML {path.relative_to(ROOT)}: {exc}")
    return "passed"


def validate_workflow(path: Path, errors: list[str]) -> dict:
    payload = json.loads(path.read_text(encoding="utf-8"))
    name = payload.get("name")
    tasks = payload.get("tasks", [])
    error_if(not isinstance(name, str) or not name.strip(), f"invalid workflow name: {path.name}", errors)
    error_if(not isinstance(tasks, list) or not tasks, f"invalid tasks: {path.name}", errors)
    ids = [task.get("id") for task in tasks]
    error_if(len(ids) != len(set(ids)), f"duplicate task IDs: {path.name}", errors)
    error_if(len(ids) > 256, f"too many tasks: {path.name}", errors)
    graph = {task["id"]: task.get("depends_on", []) for task in tasks}
    for task in tasks:
        node_id = task["id"]
        for dependency in task.get("depends_on", []):
            error_if(dependency not in graph, f"unknown dependency: {path.name}/{node_id}/{dependency}", errors)
            error_if(dependency == node_id, f"self dependency: {path.name}/{node_id}", errors)
        action = task.get("action", {})
        error_if(action.get("type") not in {"echo", "input", "collect", "sleep", "http", "fail"},
                 f"invalid action: {path.name}/{node_id}", errors)
    visited: set[str] = set()
    visiting: set[str] = set()

    def dfs(node: str) -> bool:
        if node in visiting:
            return False
        if node in visited:
            return True
        visiting.add(node)
        for dependency in graph.get(node, []):
            if dependency not in graph or not dfs(dependency):
                return False
        visiting.remove(node)
        visited.add(node)
        return True

    for node in ids:
        if node not in visited and not dfs(node):
            errors.append(f"cyclic or invalid DAG in {path.name}")
            break
    return {"name": name, "tasks": len(tasks)}



def optional_rust_lexical_check(rust_files: list[Path], errors: list[str]) -> str:
    """Check basic tokenization and delimiter nesting, not type checking."""
    try:
        from pygments import lex
        from pygments.lexers import RustLexer
        from pygments.token import Error, Punctuation
    except ImportError:
        return "not available (Pygments not installed)"
    matched = {")": "(", "]": "[", "}": "{"}
    for path in rust_files:
        stack: list[str] = []
        for token, value in lex(path.read_text(encoding="utf-8"), RustLexer()):
            if token in Error:
                errors.append(f"Rust tokenization error in {path.relative_to(ROOT)}: {value!r}")
            if token in Punctuation:
                for character in value:
                    if character in "([{":
                        stack.append(character)
                    elif character in matched:
                        if not stack or stack.pop() != matched[character]:
                            errors.append(f"unmatched Rust delimiter {character!r} in {path.relative_to(ROOT)}")
        if stack:
            errors.append(f"unclosed Rust delimiters in {path.relative_to(ROOT)}")
    return "passed" if not errors else "failed (see errors)"


def main() -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--json", metavar="PATH", help="write machine-readable audit JSON to this path")
    args = parser.parse_args()
    errors: list[str] = []
    for relative in REQUIRED_FILES:
        error_if(not (ROOT / relative).is_file(), f"missing {relative}", errors)

    workspace = tomllib.loads((ROOT / "Cargo.toml").read_text(encoding="utf-8"))
    members = workspace.get("workspace", {}).get("members", [])
    error_if(len(members) != 4, f"expected four workspace members, found {len(members)}", errors)
    for member in members:
        manifest = ROOT / member / "Cargo.toml"
        error_if(not manifest.is_file(), f"workspace manifest missing: {member}", errors)
        if manifest.is_file():
            tomllib.loads(manifest.read_text(encoding="utf-8"))
        error_if(not (ROOT / member / "src" / "lib.rs").is_file() and
                 not (ROOT / member / "src" / "main.rs").is_file(),
                 f"workspace source missing: {member}", errors)

    examples = {}
    for path in sorted((ROOT / "examples").glob("*.json")):
        try:
            examples[path.name] = validate_workflow(path, errors)
        except (KeyError, TypeError, ValueError, json.JSONDecodeError) as exc:
            errors.append(f"workflow example invalid: {path.name}: {exc}")
    error_if(len(examples) < 3, "expected at least 3 workflow examples", errors)

    yaml_files = [ROOT / "docker-compose.yml"] + list((ROOT / ".github").rglob("*.yml"))
    yaml_status = yaml_check(yaml_files, errors)

    rust_files = sorted(path for path in ROOT.rglob("*.rs") if not IGNORED_PARTS.intersection(path.relative_to(ROOT).parts))
    error_if(len(rust_files) < 6, "too few Rust sources", errors)
    rust_lexing_status = optional_rust_lexical_check(rust_files, errors)
    rust_physical_loc = 0
    rust_nonblank_loc = 0
    rust_nonblank_noncomment_loc = 0
    tests = 0
    rust_hashes: dict[str, str] = {}
    for path in rust_files:
        text = path.read_text(encoding="utf-8")
        data = path.read_bytes()
        lines = text.splitlines()
        rust_physical_loc += len(lines)
        rust_nonblank_loc += sum(bool(line.strip()) for line in lines)
        rust_nonblank_noncomment_loc += sum(
            bool(line.strip()) and not line.lstrip().startswith(("//", "/*", "*", "*/"))
            for line in lines
        )
        tests += text.count("#[test]") + text.count("#[tokio::test]")
        rust_hashes[str(path.relative_to(ROOT))] = hashlib.sha256(data).hexdigest()
    error_if(tests < 30, f"too few declared Rust tests: {tests}", errors)

    store_text = (ROOT / "crates/nexusflow-store/src/lib.rs").read_text(encoding="utf-8")
    for needle in [
        "SKIP LOCKED", "lease_expires_at", "attempts", "FOR UPDATE",
        "idempotency_key", "reap_exhausted_leases", "succeed", "cancel_run",
    ]:
        error_if(needle not in store_text, f"missing expected persistence feature: {needle}", errors)
    sql = (ROOT / "migrations/0001_init.sql").read_text(encoding="utf-8")
    for table in ["workflow_definitions", "workflow_runs", "task_runs", "task_dependencies"]:
        error_if(f"CREATE TABLE {table}" not in sql, f"missing table {table}", errors)

    history: list[str] = []
    try:
        proc = subprocess.run(
            ["git", "log", "--format=%h|%aI|%an|%s", "--reverse"],
            cwd=ROOT, check=True, capture_output=True, text=True,
        )
        history = [line for line in proc.stdout.splitlines() if line.strip()]
    except (OSError, subprocess.CalledProcessError):
        pass  # Source-only zip without .git is still valid; not a history proof.

    report = {
        "project": "NexusFlow",
        "audit_type": "static only; Rust code has NOT been compiled or executed here",
        "status": "pass" if not errors else "fail",
        "workspace_members": members,
        "rust_source_files": len(rust_files),
        "rust_physical_lines_including_tests_comments_blanks": rust_physical_loc,
        "rust_nonblank_lines_including_tests_comments": rust_nonblank_loc,
        "rust_approx_nonblank_noncomment_lines_including_tests": rust_nonblank_noncomment_loc,
        "declared_rust_tests_unexecuted": tests,
        "examples": examples,
        "yaml_parse": yaml_status,
        "optional_rust_token_and_delimiter_check": rust_lexing_status,
        "git_local_commit_records": history,
        "rust_sha256": rust_hashes,
        "requirements_not_met": [
            "100000+ authentic Rust LOC",
            "mostly human-written code",
            "real pull requests and development history over time",
            "verified company/user ownership and exclusivity",
            "certified absence of AI company access",
            "double successful runtime/compilation tests",
        ],
        "errors": errors,
    }
    if args.json:
        dest = Path(args.json)
        if not dest.is_absolute():
            dest = ROOT / dest
        dest.write_text(json.dumps(report, indent=2, sort_keys=True) + "\n", encoding="utf-8")
    print(f"Audit: {report['status'].upper()}; Rust files={len(rust_files)}, physical LOC={rust_physical_loc}, "
          f"nonblank/noncomment approx={rust_nonblank_noncomment_loc}, declared tests={tests} (UNRUN)")
    print(f"YAML: {yaml_status}; Rust lexical check: {rust_lexing_status}; Git local commits: {len(history)}")
    if errors:
        print("ERRORS:", *errors, sep="\n - ", file=sys.stderr)
    else:
        print("All offline structural checks passed; build and functional tests remain unverified.")
    return 1 if errors else 0


if __name__ == "__main__":
    sys.exit(main())
