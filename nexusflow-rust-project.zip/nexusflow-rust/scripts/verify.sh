#!/usr/bin/env bash
# Independent physical LOC check plus offline audit. Cargo checks are optional
# and never silently reported as passing when Rust is unavailable.
set -euo pipefail
cd "$(dirname "$0")/.."

physical_shell=0
count=0
while IFS= read -r -d '' file; do
  number=$(wc -l < "$file")
  physical_shell=$((physical_shell + number))
  count=$((count + 1))
done < <(find apps crates -type f -name '*.rs' -print0)

physical_python=$(python3 - <<'PY'
from pathlib import Path
print(sum(len(path.read_text(encoding='utf-8').splitlines()) for path in Path('.').rglob('*.rs')
          if '.git' not in path.parts and 'target' not in path.parts))
PY
)

printf 'Independent LOC count A (wc -l): %s Rust files, %s physical lines\n' "$count" "$physical_shell"
printf 'Independent LOC count B (Python splitlines): %s physical lines\n' "$physical_python"
if [ "$physical_shell" -ne "$physical_python" ]; then
  echo 'FAIL: independent line counts disagree' >&2
  exit 1
fi
echo 'PASS: physical Rust LOC counts agree'

git diff --check
git diff --cached --check
python3 scripts/audit.py

echo 'Checking compiler availability...'
if ! command -v cargo >/dev/null 2>&1; then
  echo 'NOT VERIFIED: cargo/rustc are unavailable; Rust tests/build were NOT run.'
  if [[ "${1:-}" == '--cargo' ]]; then
    exit 2
  fi
  exit 0
fi
if [[ "${1:-}" != '--cargo' ]]; then
  echo 'NOT RUN: cargo checks are optional; use scripts/verify.sh --cargo with PostgreSQL.'
  exit 0
fi
if [[ -z "${DATABASE_URL:-}" ]]; then
  echo 'DATABASE_URL required for PostgreSQL integration tests' >&2
  exit 2
fi
cargo fmt --all -- --check
cargo clippy --workspace --all-targets -- -D warnings
cargo test --workspace -- --test-threads=1
cargo build --release --workspace
echo 'PASS: complete Rust checks and release build succeeded.'
