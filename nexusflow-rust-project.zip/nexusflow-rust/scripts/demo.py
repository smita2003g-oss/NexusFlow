#!/usr/bin/env python3
"""Exercise a live NexusFlow API using only the Python standard library."""

from __future__ import annotations

import argparse
import json
from pathlib import Path
import sys
import time
from urllib.error import HTTPError, URLError
from urllib.request import Request, urlopen
from uuid import uuid4


def request_json(method: str, url: str, token: str, payload: dict | None = None,
                 key: str | None = None) -> dict:
    data = None if payload is None else json.dumps(payload).encode("utf-8")
    headers = {"Authorization": f"Bearer {token}"}
    if payload is not None:
        headers["Content-Type"] = "application/json"
    if key is not None:
        headers["Idempotency-Key"] = key
    request = Request(url, data=data, headers=headers, method=method)
    try:
        with urlopen(request, timeout=10) as response:
            return json.load(response)
    except HTTPError as exc:
        detail = exc.read(4_096).decode("utf-8", errors="replace")
        raise RuntimeError(f"HTTP {exc.code}: {detail}") from exc
    except URLError as exc:
        raise RuntimeError(f"API unreachable: {exc}") from exc


def main() -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--base", default="http://127.0.0.1:8080")
    parser.add_argument("--token", required=True)
    parser.add_argument("--workflow", type=Path,
                        default=Path(__file__).resolve().parents[1] / "examples/hello-dag.json")
    parser.add_argument("--timeout", type=int, default=30)
    args = parser.parse_args()
    workflow = json.loads(args.workflow.read_text(encoding="utf-8"))
    base = args.base.rstrip("/")
    created = request_json("POST", f"{base}/v1/workflows", args.token, workflow)
    workflow_id = created["id"]
    print(f"Workflow: {workflow_id}")
    started = request_json("POST", f"{base}/v1/workflows/{workflow_id}/runs", args.token,
                           {"input": {"username": "Ada", "source": "python-demo"}},
                           key=f"demo-{uuid4()}")
    run_id = started["run_id"]
    print(f"Run: {run_id}")
    deadline = time.monotonic() + max(1, args.timeout)
    while time.monotonic() < deadline:
        run = request_json("GET", f"{base}/v1/runs/{run_id}", args.token)
        if run["status"] in ("succeeded", "failed", "canceled"):
            print(json.dumps(run, indent=2))
            return 0 if run["status"] == "succeeded" else 1
        time.sleep(0.25)
    print(f"TIMED OUT: inspect /v1/runs/{run_id}", file=sys.stderr)
    return 2


if __name__ == "__main__":
    try:
        sys.exit(main())
    except (OSError, RuntimeError, KeyError, ValueError) as exc:
        print(f"ERROR: {exc}", file=sys.stderr)
        sys.exit(1)
