# Contributing to NexusFlow

We are building a legitimate Rust workflow engine. Contributions must represent real work: issue-driven changes, author-owned commits, human-reviewed pull requests, tests and documentation.

1. Open an issue with problem statement, acceptance tests and owner.
2. Create a branch off `main` using your actual identity and timestamps.
3. Implement a small, reviewable change. Add unit/integration tests for correctness and concurrent cases.
4. Run formatting, lint and PostgreSQL tests. Include evidence and failure analysis in the PR.
5. Request review from an independent human engineer; record decisions in the PR.
6. Keep each commit's author, date, message and contents truthful; avoid squashing away context unless the project policy requires it.
7. State AI assistance **honestly** in the pull request, even when it is a small percentage. Do not claim AI-generated code was human-authored.

## Definition of done

- Correctness: behavior is observable and deterministic where promised.
- Safety: task recovery avoids stale lease updates; HTTP execution and secrets are reviewed.
- Tests: success, failure, timeout, expiry, concurrency and cancel cases where applicable.
- Operations: logs, migration/rollback plan, metrics and runbook changes when needed.
- Context: documentation, linked issues, PR reviews and decisions tell *why* code changed.

## Project history expectations

The zip/bundle here is an initial AI-generated scaffold created in one session. Its commits are real local actions, not evidence of a long-lived engineering team. Pull requests cannot be fabricated offline. A qualifying project history must emerge through actual independent engineering work over time, and be verified against the live GitHub repository.
