# ADR 0001: PostgreSQL as authoritative workflow queue

**Status:** Accepted for experimental MVP

## Context

Workflow state must survive service restarts, and task claims need to be safely shared among independent processes. Adding Redis/Kafka beside the run database introduces a cross-system consistency boundary that requires an outbox/inbox protocol before reliable handoff.

## Decision

PostgreSQL stores run states, task states and dependency edges. Workers poll directly using `FOR UPDATE SKIP LOCKED` and update fencing metadata in the claim transaction. All status transitions remain in one authoritative database. Use SQL migrations rather than dynamically initializing tables in application code.

## Consequences

**Benefits:** simple deployment, durable writes, transactional graph insertion, familiar operations, no separate queue outage or dual-write issue in the MVP.

**Costs:** polling load, fairness limitations, database contention under large worker counts, no fan-out routing infrastructure, and reliance on PostgreSQL uptime. We will measure actual throughput and revisit a Kafka/Redis Streams design only when workload metrics justify the additional complexity.

## Revisit when

Sustained queue volume, query contention, replication or cross-region requirements exceed a tested PostgreSQL budget. This decision is not a throughput benchmark.
