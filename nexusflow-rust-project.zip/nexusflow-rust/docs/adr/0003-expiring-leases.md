# ADR 0003: Expiring leases and serialization on parent run

**Status:** Accepted for experimental MVP

## Context

Multiple workers may finish the last tasks of a workflow concurrently. If each checks readiness without serialization, both transactions may see the other task as incomplete and leave the workflow falsely running. Separately, expired leases must be reclaimed without letting old workers write stale task results.

## Decision

Use a monotonically increasing attempt field as the fencing token. Heartbeats and task completion compare owner, attempt and lease expiry. Serialize task completion across one workflow by locking its parent `workflow_runs` row before task writes. The reaper locks parent rows first and atomically marks final-expired tasks and their runs failed.

## Consequences

- Parallel tasks within the same workflow can execute independently, but their final database commits serialize on one parent row.
- This is simple and correct for small-to-medium DAGs, but a very wide workflow may need a different finalization strategy after benchmarking.
- Long-running actions must heartbeat; the worker uses a cooperative Tokio select loop.
- Process death during external work can lead to delivery duplication; fencing alone is not an external transaction protocol.
