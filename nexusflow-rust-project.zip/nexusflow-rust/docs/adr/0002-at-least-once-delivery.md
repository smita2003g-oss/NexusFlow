# ADR 0002: At-least-once task execution and fencing

**Status:** Accepted for experimental MVP

## Context

An external HTTP call and a PostgreSQL completion write cannot be atomically committed without a protocol supported by the external system. A process can crash after the remote side effect but before recording success.

## Decision

Promise **at least once** rather than exactly once. Every task claim increments a fencing counter (`attempts`). Completion and heartbeat compare both the worker ID and counter, with lease validity checked at update time. HTTP tasks emit an idempotency key stable for the run/node pair; remote systems must implement deduplication themselves. Attempts are bounded; final lease exhaustion fails the workflow.

## Consequences

- On any crash, duplicate external effects are possible.
- A worker cannot commit its stale result to NexusFlow after another worker has reclaimed its task.
- HTTP retries may happen even if the target succeeded but response was lost.
- For financial or irreversible commands, the receiving system needs its own durable inbox/deduplication design and compensations.

## Revisit when

A concrete external system supports transactions, idempotent request handling or deduplication receipts that can offer stronger end-to-end semantics.
