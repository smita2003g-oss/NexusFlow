# Sustainable roadmap: from an MVP to a real large engineering codebase

The request for 100,000+ lines **cannot be met ethically by padding or programmatically duplicating code**. This roadmap describes useful independent functionality that could justify substantial real Rust code and produce real GitHub issues, reviews and long-lived team history. Estimates are **not existing lines** and **not a promise**.

## Phase 0 — verify starter and establish ownership

- Set up a real repository under the authorized company/user account.
- Confirm the license and contributor chain of title; record AI use. Do not relabel AI-generated commits as human authorship.
- Install Rust, generate and commit `Cargo.lock`, run formatting and Clippy, make compile fixes, then get CI green.
- Run PostgreSQL integration tests against an isolated database and record outcomes.
- Threat-model outbound HTTP tasks, add restricted egress and a resolution-aware URL/IP allowlist.
- Hold architecture review and record the approved initial ADRs.

## Phase 1 — reliability and tenancy

Suggested real tickets: fine-grained tenants, role-based auth, tenant quotas, workflow versioning, run events/audit log, encrypted secrets, schedule triggers, backfill tools, idempotency inbox, bounded payloads, compensations, task priority, stalled-run detector, dead-letter table, result retention and export.

Required evidence: unit tests for every state transition, transaction-interleaving tests, failure injection, repeatable benchmark harness, rollout and migration plan.

## Phase 2 — production workers

Suggested work: executor plugin SDK, sandboxed command tasks, callback/webhook triggers, isolated task processes, worker draining, HTTP allowlist, Kubernetes deployments, service-specific pools, retries with jitter, per-tenant fairness, metrics/OTel traces, dashboards, rate limiting, audit redaction and verified backup/restore drills.

Required evidence: multi-node chaos tests under repeated worker/network restarts, reproducible load testing, SLOs, production incident simulations and security reviews.

## Phase 3 — richer workflow orchestration

Suggested work: dynamic DAG expansion, fan-out/fan-in, foreach, typed schemas, event/cron triggers, workflow subscriptions, durable timers, waiting for human approvals, pause/resume/replay, multiple versions, conditional routing, compensation steps, edge case diagnostics and workflow execution visualization.

Required evidence: forward/backward compatibility tests, state machine/model-based tests, migration testing and documentation for service operators.

## Phase 4 — ecosystem, developer experience and sustained history

Suggested work: CLI, typed Rust/Go/TypeScript SDKs, web UI, tracing UI, integrations, workflow lint language server, API schema generation, demo gallery, Kubernetes Helm charts, operator, capacity planning guide, multi-region design experiments, adoption telemetry (with consent) and durable release automation.

Required evidence: actual GitHub pull requests with approvals, contributor attribution, released versions, documented incidents/decisions, license review, meaningful code-coverage measurement and outside security audits.

## Line-count and provenance policy

1. Report both **physical Rust lines** and **nonblank/noncomment authored Rust lines**, separately from docs, tests and generated files.
2. Exclude dependencies, `target/`, codegen, minified files, repeated fillers and vendored code from the qualifying owned count.
3. Never claim a human-majority contribution ratio from a commit count alone; use honest contribution accounting and substantively human-developed features.
4. Never invent PRs, reviews, external users, a startup's history or an earlier creation date.
5. Verify metrics against the actual live GitHub repo and contributor license records before submitting to any organization with minimum size/history/team constraints.
