# NexusFlow architecture and invariants

## Scope

The initial engine runs a fixed DAG declared at workflow creation time. Nodes are immutable for the lifetime of a run. Runs are independent instances with caller-provided JSON input. The server and workers are separate processes sharing PostgreSQL. Workers can be replicated horizontally without a central coordinator.

## Ownership of state

| Table | Purpose | Important invariant |
| --- | --- | --- |
| `workflow_definitions` | Immutable DAG definitions and action configuration | Workflow validates before insert |
| `workflow_runs` | Workflow instance input and terminal state | Exactly one terminal state; never reopen |
| `task_runs` | Attempts, lease, output and error per node | Unique `(run_id,node_id)`; claim is atomic |
| `task_dependencies` | Predecessors by node ID | Child cannot claim until all predecessors succeed |

### State transitions

```text
                       recover expired lease (< max attempts)
                         +---------------------------+
                         |                           |
                         v                           |
   pending --------> running ------success------> succeeded
                         |
                         +-- retryable error and attempts remain --> retry_wait
                         |                                          |
                         |                               due time --+
                         +-- permanent error / exhausted attempts --> failed
                         |
   pending, running, retry_wait -----------------------------> canceled
```

A workflow run begins in `running` and ends in `succeeded`, `failed`, or `canceled`. A task that fails permanently makes its workflow fail; unfinished tasks are left as historical `pending`/`retry_wait` or `running` records but cannot be claimed again because the parent run is terminal. A future production revision should transition remaining tasks to `skipped`/`canceled` for clearer reporting and enforce retention.

## Algorithm: claim

1. A worker polls `Store::claim()` for a task with remaining attempts and a running parent.
2. Eligible task is `pending`/`retry_wait` and due, or `running` with an expired lease.
3. SQL rejects tasks with any predecessor task not yet `succeeded`.
4. The query orders candidates and selects one with `FOR UPDATE OF t SKIP LOCKED LIMIT 1`.
5. In the same statement, update task status, `lease_owner`, `lease_expires_at` and increment `attempts`. This attempt number is the fencing token.
6. Worker reads immutable workflow definition/run input/predecessor outputs, and executes the declared action.

`SKIP LOCKED` distributes claims across processes while avoiding a global lock. It does not provide strict FIFO fairness or a full message queue's routing/scheduling guarantees.

## Algorithm: heartbeat and completion

A worker heartbeats at about one third of the lease duration. Each write requires `task ID`, `lease_owner`, `attempts`, `status='running'` and a non-expired lease. Heartbeats also require a running parent run. If a lease has expired and another worker reclaimed the task, the old worker's write is rejected.

Successful or failed task completion acquires `SELECT ... FROM workflow_runs FOR UPDATE` **before** changing the child task. This ensures two workers completing the final independent tasks cannot both read a stale predecessor state and leave a fully successful workflow marked `running`.

Worker processes are not prevented from making an external HTTP side effect just before losing their lease. Fencing protects **NexusFlow database state**, not systems that ignore the idempotency key. External consumers should deduplicate by `nexusflow:{run-id}:{node-id}` or maintain their own operation log.

## Failure and recovery

- The engine uses explicit per-task `max_attempts`, 1 to 20 (default 3).
- Action failures retry with an exponential delay (2, 4, 8, ... up to 256 seconds). Nonretryable HTTP 4xx fail immediately, except retryable 408/429.
- A crashed process stops heartbeating; once the lease expires, another worker may reclaim the task if attempts remain.
- A worker's final attempt that expires is not reclaimable. A reaper marks its task and workflow failed **in one PostgreSQL transaction** after locking parent workflow rows first.
- If the PostgreSQL connection is unavailable, workers log errors; the task remains leased until expiration. Pending tasks stay durable.
- Canceling a run revokes all unfinished task leases and prevents future claims. Network side effects already committed outside NexusFlow cannot be undone.

## Isolation, ordering and consistency

PostgreSQL's default `READ COMMITTED` isolation is used. Row locks and transactional updates enforce scheduler invariants. New runs are inserted with tasks and dependency edges in a single database transaction. A unique `(workflow_id,idempotency_key)` ensures retries of the start request do not create duplicate runs. Concurrent inserts wait on the unique constraint and then fetch the existing run ID.

The database should not be modified externally without respecting these invariants; editing mutable JSON/workflows in place breaks the scheduler. `claim()` is not intended to be called outside the worker loop except in integration tests.

## Crash consistency matrix

| Crash point | Durable database outcome | Recovery |
| --- | --- | --- |
| Before run transaction commit | No partial run should exist | Client retries with key |
| After run commit, before API reply | Full run exists | Same key returns original run |
| Before claim statement commits | Task remains available | Any worker claims |
| After claim, before action | Running with lease | Reclaim after expiry |
| After remote action, before result write | Side effect may exist without success recorded | Receiver must deduplicate retry |
| During success/failure transaction | Atomic commit or rollback | Old lease eventually expires |
| After final attempt expires | Running task until reaper | Reaper marks task/run failed atomically |
| After cancel | Run and unfinished tasks canceled | Workers' fenced writes fail |

## Scaling strategy

- Scale workers horizontally, with per-worker concurrency limited by PostgreSQL connections and target service capacity.
- Separate CPU-heavy actions from asynchronous HTTP/sleep actions in a future executor-pool abstraction; avoid blocking Tokio threads.
- Prefer deployment egress policies and authentication isolation over treating user-defined URLs as safe.
- Add metrics for queue depth, claim latency, retries, lease expiration, task duration and failure classes before production scaling.
- Run load, interruption and chaos tests using synthetic workflows. No throughput or reliability target has yet been measured.

## Open technical debt

1. HTTP SSRF: an exact hostname allowlist exists but DNS rebinding/private-IP blocking does not; a restricted worker network is mandatory.
2. Single shared bearer token; no multitenancy or RBAC.
3. No global `max_running` quota or per-tenant fairness.
4. No persistent action-level deduplication for non-HTTP side effects.
5. No dead-letter queue, human-in-the-loop approval or manual retry route.
6. No retention/archival/garbage collection and no workflow version migration policy.
7. Task-run outputs returned by API are not subject to redaction or size limits except HTTP result cap.
8. No full distributed load test, OS resource isolation, hardened TLS or deployment health probes.
9. No scheduled/cron triggers, partial DAG regeneration or dynamic task fanout.
10. No locally executed Rust compiler/test report for this initial scaffold.
