//! HTTP control plane for NexusFlow.
//! All /v1 endpoints require an API bearer token.

use axum::{
    extract::{Path, Query, State},
    http::{header::AUTHORIZATION, Request, StatusCode},
    middleware::{self, Next},
    response::{IntoResponse, Response},
    routing::{get, post},
    Json, Router,
};
use nexusflow_core::WorkflowDefinition;
use nexusflow_store::{RunView, StartResult, Store, WorkflowRecord};
use serde::{Deserialize, Serialize};
use serde_json::{json, Value};
use subtle::ConstantTimeEq;
use tower_http::trace::TraceLayer;
use uuid::Uuid;

#[derive(Clone)]
pub struct AppState {
    pub store: Store,
    pub api_token: String,
}

pub fn router(state: AppState) -> Router {
    let protected = Router::new()
        .route("/v1/workflows", post(create_workflow).get(list_workflows))
        .route("/v1/workflows/{id}", get(get_workflow))
        .route("/v1/workflows/{id}/runs", post(start_run))
        .route("/v1/runs/{id}", get(get_run))
        .route("/v1/runs/{id}/cancel", post(cancel_run))
        .route_layer(middleware::from_fn_with_state(state.clone(), authorize));
    Router::new()
        .route("/healthz", get(health))
        .route("/readyz", get(ready))
        .merge(protected)
        .layer(TraceLayer::new_for_http())
        .with_state(state)
}

async fn authorize(State(state): State<AppState>, request: Request<axum::body::Body>, next: Next) -> Response {
    // Avoid naive secret-string comparisons; terminate HTTPS at the reverse proxy.
    let valid = request
        .headers()
        .get(AUTHORIZATION)
        .and_then(|value| value.to_str().ok())
        .and_then(|value| value.strip_prefix("Bearer "))
        .is_some_and(|value| value.as_bytes().ct_eq(state.api_token.as_bytes()).unwrap_u8() == 1);
    if !valid {
        return (
            StatusCode::UNAUTHORIZED,
            Json(json!({"error": "missing or invalid bearer token"})),
        )
            .into_response();
    }
    next.run(request).await
}

#[derive(Debug)]
enum ApiError {
    NotFound,
    Conflict(&'static str),
    BadRequest(String),
    Internal(anyhow::Error),
}

impl IntoResponse for ApiError {
    fn into_response(self) -> Response {
        match self {
            Self::NotFound => (StatusCode::NOT_FOUND, Json(json!({"error":"not found"}))).into_response(),
            Self::Conflict(message) => {
                (StatusCode::CONFLICT, Json(json!({"error":message}))).into_response()
            }
            Self::BadRequest(message) => {
                (StatusCode::BAD_REQUEST, Json(json!({"error":message}))).into_response()
            }
            Self::Internal(error) => {
                tracing::error!(?error, "request failed");
                (StatusCode::INTERNAL_SERVER_ERROR, Json(json!({"error":"internal server error"})))
                    .into_response()
            }
        }
    }
}

fn internal(error: anyhow::Error) -> ApiError {
    ApiError::Internal(error)
}

async fn health() -> Json<Value> {
    Json(json!({"status":"ok", "service":"nexusflow-server"}))
}

async fn ready(State(state): State<AppState>) -> StatusCode {
    match state.store.ping().await {
        Ok(()) => StatusCode::OK,
        Err(error) => {
            tracing::warn!(?error, "database not ready");
            StatusCode::SERVICE_UNAVAILABLE
        }
    }
}

async fn create_workflow(
    State(state): State<AppState>,
    Json(definition): Json<WorkflowDefinition>,
) -> Result<(StatusCode, Json<WorkflowRecord>), ApiError> {
    definition
        .validate()
        .map_err(|error| ApiError::BadRequest(error.to_string()))?;
    let record = state.store.create_workflow(&definition).await.map_err(internal)?;
    Ok((StatusCode::CREATED, Json(record)))
}

#[derive(Deserialize)]
struct ListQuery {
    limit: Option<i64>,
}

async fn list_workflows(
    State(state): State<AppState>,
    Query(query): Query<ListQuery>,
) -> Result<Json<Vec<WorkflowRecord>>, ApiError> {
    let records = state
        .store
        .list_workflows(query.limit.unwrap_or(50))
        .await
        .map_err(internal)?;
    Ok(Json(records))
}

async fn get_workflow(
    State(state): State<AppState>,
    Path(id): Path<Uuid>,
) -> Result<Json<WorkflowRecord>, ApiError> {
    state
        .store
        .get_workflow(id)
        .await
        .map_err(internal)?
        .map(Json)
        .ok_or(ApiError::NotFound)
}

#[derive(Debug, Deserialize)]
struct StartRunRequest {
    #[serde(default = "default_input")]
    input: Value,
}

fn default_input() -> Value {
    json!({})
}

#[derive(Debug, Serialize)]
struct StartRunResponse {
    run_id: Uuid,
    created: bool,
}

async fn start_run(
    State(state): State<AppState>,
    Path(id): Path<Uuid>,
    headers: axum::http::HeaderMap,
    Json(body): Json<StartRunRequest>,
) -> Result<(StatusCode, Json<StartRunResponse>), ApiError> {
    let key = headers
        .get("Idempotency-Key")
        .map(|value| value.to_str())
        .transpose()
        .map_err(|_| ApiError::BadRequest("invalid idempotency header".into()))?;
    if key.is_some_and(|value| value.is_empty() || value.len() > 200) {
        return Err(ApiError::BadRequest("idempotency key must be 1..=200 bytes".into()));
    }
    if state.store.get_workflow(id).await.map_err(internal)?.is_none() {
        return Err(ApiError::NotFound);
    }
    let StartResult { run_id, created } = state
        .store
        .start_run(id, body.input, key)
        .await
        .map_err(internal)?;
    let status = if created { StatusCode::CREATED } else { StatusCode::OK };
    Ok((status, Json(StartRunResponse { run_id, created })))
}

async fn get_run(
    State(state): State<AppState>,
    Path(id): Path<Uuid>,
) -> Result<Json<RunView>, ApiError> {
    state
        .store
        .get_run(id)
        .await
        .map_err(internal)?
        .map(Json)
        .ok_or(ApiError::NotFound)
}

async fn cancel_run(
    State(state): State<AppState>,
    Path(id): Path<Uuid>,
) -> Result<Json<Value>, ApiError> {
    if state.store.cancel_run(id).await.map_err(internal)? {
        return Ok(Json(json!({"run_id":id,"status":"canceled"})));
    }
    if state.store.get_run(id).await.map_err(internal)?.is_none() {
        Err(ApiError::NotFound)
    } else {
        Err(ApiError::Conflict("run is already terminal"))
    }
}

#[cfg(test)]
mod tests {
    use super::*;
    use axum::body::Body;
    use sqlx::postgres::PgPoolOptions;
    use tower::ServiceExt;

    fn app() -> Router {
        let pool = PgPoolOptions::new()
            .connect_lazy("postgres://nexusflow:nexusflow@localhost/nexusflow")
            .expect("valid DSN");
        router(AppState {
            store: Store::from_pool(pool),
            api_token: "at-least-16-character-secret".to_owned(),
        })
    }

    #[tokio::test]
    async fn health_check_is_public() {
        let response = app()
            .oneshot(Request::builder().uri("/healthz").body(Body::empty()).unwrap())
            .await
            .unwrap();
        assert_eq!(response.status(), StatusCode::OK);
    }

    #[tokio::test]
    async fn private_api_requires_token() {
        let response = app()
            .oneshot(Request::builder().uri("/v1/workflows").body(Body::empty()).unwrap())
            .await
            .unwrap();
        assert_eq!(response.status(), StatusCode::UNAUTHORIZED);
    }

    #[tokio::test]
    async fn incorrect_token_is_rejected() {
        let response = app()
            .oneshot(
                Request::builder()
                    .uri("/v1/workflows")
                    .header(AUTHORIZATION, "Bearer wrong")
                    .body(Body::empty())
                    .unwrap(),
            )
            .await
            .unwrap();
        assert_eq!(response.status(), StatusCode::UNAUTHORIZED);
    }

    #[tokio::test]
    async fn unknown_route_is_not_found() {
        let response = app()
            .oneshot(Request::builder().uri("/does-not-exist").body(Body::empty()).unwrap())
            .await
            .unwrap();
        assert_eq!(response.status(), StatusCode::NOT_FOUND);
    }
}
