use anyhow::{Context, Result};
use nexusflow_server::{router, AppState};
use nexusflow_store::Store;
use std::env;
use tracing_subscriber::EnvFilter;

#[tokio::main]
async fn main() -> Result<()> {
    tracing_subscriber::fmt()
        .with_env_filter(EnvFilter::try_from_default_env().unwrap_or_else(|_| "info".into()))
        .init();
    let database_url = env::var("DATABASE_URL").context("DATABASE_URL must be set")?;
    let token = env::var("NEXUSFLOW_API_TOKEN").context("NEXUSFLOW_API_TOKEN must be set")?;
    anyhow::ensure!(token.len() >= 16, "NEXUSFLOW_API_TOKEN must be at least 16 bytes");
    let address = env::var("NEXUSFLOW_BIND").unwrap_or_else(|_| "0.0.0.0:8080".into());

    let store = Store::connect(&database_url, 10).await?;
    store.migrate().await?;
    let app = router(AppState { store, api_token: token });
    let listener = tokio::net::TcpListener::bind(&address).await?;
    tracing::info!(address = %address, "NexusFlow API listening");
    axum::serve(listener, app)
        .with_graceful_shutdown(async {
            let _ = tokio::signal::ctrl_c().await;
        })
        .await?;
    Ok(())
}
