use anyhow::{Context, Result};
use nexusflow_core::retry_delay_seconds;
use nexusflow_store::{ClaimedTask, Store};
use nexusflow_worker::{execute, http_client, ExecuteFailure};
use std::{env, sync::Arc, time::Duration};
use tokio::{sync::Semaphore, task::JoinSet, time::MissedTickBehavior};
use tracing_subscriber::EnvFilter;
use uuid::Uuid;

#[derive(Clone)]
struct WorkerSettings {
    id: String,
    lease_seconds: i64,
    allow_http: bool,
    allowed_hosts: Vec<String>,
    poll_ms: u64,
}

#[tokio::main]
async fn main() -> Result<()> {
    tracing_subscriber::fmt()
        .with_env_filter(EnvFilter::try_from_default_env().unwrap_or_else(|_| "info".into()))
        .init();

    let database_url = env::var("DATABASE_URL").context("DATABASE_URL must be set")?;
    let parallelism = env_int("NEXUSFLOW_CONCURRENCY", 8).clamp(1, 64) as usize;
    let lease_seconds = env_int("NEXUSFLOW_LEASE_SECONDS", 60).clamp(10, 3600);
    let poll_ms = env_int("NEXUSFLOW_POLL_MS", 250).clamp(50, 60_000) as u64;
    let hostname = env::var("HOSTNAME").unwrap_or_else(|_| "worker".into());
    let settings = WorkerSettings {
        id: format!("{hostname}-{}", Uuid::new_v4()),
        lease_seconds,
        allow_http: env::var("NEXUSFLOW_ALLOW_HTTP").is_ok_and(|v| v == "true"),
        allowed_hosts: env::var("NEXUSFLOW_ALLOWED_HTTP_HOSTS")
            .unwrap_or_default()
            .split(',')
            .map(str::trim)
            .filter(|host| !host.is_empty())
            .map(str::to_ascii_lowercase)
            .collect(),
        poll_ms,
    };
    let store = Store::connect(&database_url, (parallelism as u32 + 4).min(32)).await?;
    store.migrate().await?;
    let client = http_client()?;
    let semaphore = Arc::new(Semaphore::new(parallelism));
    let mut tasks = JoinSet::new();

    tracing::info!(worker=%settings.id, parallelism, "worker started");
    loop {
        let permit = tokio::select! {
            _ = tokio::signal::ctrl_c() => break,
            result = semaphore.clone().acquire_owned() => result?,
        };
        if let Err(error) = store.reap_exhausted_leases().await {
            tracing::error!(?error, "lease reaper failed");
        }
        match store.claim(&settings.id, settings.lease_seconds).await {
            Ok(Some(task)) => {
                let store = store.clone();
                let client = client.clone();
                let settings = settings.clone();
                tasks.spawn(async move {
                    let _permit = permit;
                    if let Err(error) = process_task(&store, &client, &settings, task).await {
                        tracing::error!(?error, "task processing error");
                    }
                });
            }
            Ok(None) => {
                drop(permit);
                tokio::select! {
                    _ = tokio::signal::ctrl_c() => break,
                    _ = tokio::time::sleep(Duration::from_millis(settings.poll_ms)) => {},
                }
            }
            Err(error) => {
                drop(permit);
                tracing::error!(?error, "claim failed");
                tokio::time::sleep(Duration::from_millis(1_000)).await;
            }
        }
        while tasks.try_join_next().is_some() {}
    }
    // Allow in-flight tasks up to 30s to finish. Any remaining task is
    // recovered by the lease/attempt protocol after process exit.
    let deadline = tokio::time::Instant::now() + Duration::from_secs(30);
    while !tasks.is_empty() {
        let remaining = deadline.saturating_duration_since(tokio::time::Instant::now());
        if remaining.is_zero() || tokio::time::timeout(remaining, tasks.join_next()).await.is_err() {
            break;
        }
    }
    tracing::info!("worker stopped");
    Ok(())
}

fn env_int(key: &str, default: i64) -> i64 {
    env::var(key)
        .ok()
        .and_then(|value| value.parse::<i64>().ok())
        .unwrap_or(default)
}

async fn process_task(
    store: &Store,
    client: &reqwest::Client,
    settings: &WorkerSettings,
    task: ClaimedTask,
) -> Result<()> {
    tracing::info!(run=%task.run_id, node=%task.node_id, attempt=task.attempts, "task started");
    let mut heartbeats = tokio::time::interval(Duration::from_secs((settings.lease_seconds / 3).max(1) as u64));
    heartbeats.set_missed_tick_behavior(MissedTickBehavior::Skip);
    let action = async {
        match tokio::time::timeout(
            Duration::from_secs(task.definition.timeout_seconds as u64),
            execute(&task, client, settings.allow_http, &settings.allowed_hosts),
        )
        .await
        {
            Ok(result) => result,
            Err(_) => Err(ExecuteFailure::Retryable("task timeout exceeded".into())),
        }
    };
    tokio::pin!(action);
    let outcome = loop {
        tokio::select! {
            result = &mut action => break result,
            _ = heartbeats.tick() => {
                if !store.heartbeat(&task, &settings.id, settings.lease_seconds).await? {
                    tracing::warn!(run=%task.run_id, node=%task.node_id, "lease lost; abandon result");
                    return Ok(());
                }
            }
        }
    };
    match outcome {
        Ok(output) => {
            if store.succeed(&task, &settings.id, output).await? {
                tracing::info!(run=%task.run_id, node=%task.node_id, "task succeeded");
            } else {
                tracing::warn!(run=%task.run_id, node=%task.node_id, "success discarded after lease loss");
            }
        }
        Err(error) => {
            let delay = retry_delay_seconds(task.attempts);
            if store.fail(&task, &settings.id, &error.to_string(), error.retryable(), delay).await? {
                tracing::warn!(run=%task.run_id, node=%task.node_id, ?error, "task failed or queued for retry");
            }
        }
    }
    Ok(())
}
