//! Task executors. Actions may execute more than once on crashes or lease loss.

use nexusflow_core::{HttpMethod, TaskAction};
use nexusflow_store::ClaimedTask;
use reqwest::{redirect::Policy, Client, Method};
use serde_json::Value;
use std::time::Duration;
use thiserror::Error;

const MAX_HTTP_RESPONSE_BYTES: usize = 1_048_576;

#[derive(Debug, Error)]
pub enum ExecuteFailure {
    #[error("retryable execution failure: {0}")]
    Retryable(String),
    #[error("non-retryable execution failure: {0}")]
    Permanent(String),
}

impl ExecuteFailure {
    pub fn retryable(&self) -> bool {
        matches!(self, Self::Retryable(_))
    }
}

pub fn http_client() -> Result<Client, reqwest::Error> {
    Client::builder()
        .redirect(Policy::none())
        .timeout(Duration::from_secs(3_600))
        .user_agent("NexusFlow/0.1")
        .build()
}

pub async fn execute(
    task: &ClaimedTask,
    client: &Client,
    allow_plain_http: bool,
    allowed_hosts: &[String],
) -> Result<Value, ExecuteFailure> {
    match &task.definition.action {
        TaskAction::Echo { value } => Ok(value.clone()),
        TaskAction::Input => Ok(task.input.clone()),
        TaskAction::Collect => Ok(task.dependencies.clone()),
        TaskAction::Sleep { milliseconds } => {
            tokio::time::sleep(Duration::from_millis(*milliseconds)).await;
            Ok(Value::Null)
        }
        TaskAction::Fail { message } => Err(ExecuteFailure::Retryable(message.clone())),
        TaskAction::Http {
            url,
            method,
            body,
            body_from_input,
        } => execute_http(task, client, url, *method, body.as_ref(), *body_from_input, allow_plain_http, allowed_hosts).await,
    }
}

async fn execute_http(
    task: &ClaimedTask,
    client: &Client,
    url: &str,
    method: HttpMethod,
    body: Option<&Value>,
    body_from_input: bool,
    allow_plain_http: bool,
    allowed_hosts: &[String],
) -> Result<Value, ExecuteFailure> {
    let parsed = reqwest::Url::parse(url)
        .map_err(|error| ExecuteFailure::Permanent(format!("invalid URL: {error}")))?;
    if parsed.scheme() != "https" && !(allow_plain_http && parsed.scheme() == "http") {
        return Err(ExecuteFailure::Permanent(
            "HTTPS is required unless NEXUSFLOW_ALLOW_HTTP=true".into(),
        ));
    }
    if parsed.username() != "" || parsed.password().is_some() {
        return Err(ExecuteFailure::Permanent("URL credentials are forbidden".into()));
    }
    let allowed = parsed.host_str().is_some_and(|host| {
        allowed_hosts.iter().any(|candidate| candidate.eq_ignore_ascii_case(host))
    });
    if !allowed {
        return Err(ExecuteFailure::Permanent(
            "HTTP destination host is not in NEXUSFLOW_ALLOWED_HTTP_HOSTS".into(),
        ));
    }
    let method = match method {
        HttpMethod::Get => Method::GET,
        HttpMethod::Post => Method::POST,
        HttpMethod::Put => Method::PUT,
        HttpMethod::Patch => Method::PATCH,
    };
    let mut request = client.request(method, parsed).header(
        "Idempotency-Key",
        format!("nexusflow:{}:{}", task.run_id, task.node_id),
    );
    if body_from_input {
        request = request.json(&task.input);
    } else if let Some(body) = body {
        request = request.json(body);
    }
    let mut response = request
        .send()
        .await
        .map_err(|error| ExecuteFailure::Retryable(error.to_string()))?;
    let status = response.status();
    let mut bytes = Vec::new();
    while let Some(chunk) = response
        .chunk()
        .await
        .map_err(|error| ExecuteFailure::Retryable(error.to_string()))?
    {
        if bytes.len() + chunk.len() > MAX_HTTP_RESPONSE_BYTES {
            return Err(ExecuteFailure::Permanent("HTTP response exceeds 1 MiB".into()));
        }
        bytes.extend_from_slice(&chunk);
    }
    if !status.is_success() {
        let message = format!("HTTP {status}: {}", String::from_utf8_lossy(&bytes));
        if status.is_server_error() || status.as_u16() == 408 || status.as_u16() == 429 {
            return Err(ExecuteFailure::Retryable(message));
        }
        return Err(ExecuteFailure::Permanent(message));
    }
    if bytes.is_empty() {
        Ok(Value::Null)
    } else {
        match serde_json::from_slice(&bytes) {
            Ok(json) => Ok(json),
            Err(_) => Ok(Value::String(String::from_utf8_lossy(&bytes).into_owned())),
        }
    }
}

#[cfg(test)]
mod tests {
    use super::*;
    use nexusflow_core::TaskDefinition;
    use serde_json::json;
    use uuid::Uuid;

    fn task(action: TaskAction) -> ClaimedTask {
        ClaimedTask {
            id: Uuid::new_v4(),
            run_id: Uuid::new_v4(),
            node_id: "example".into(),
            attempts: 1,
            max_attempts: 3,
            definition: TaskDefinition {
                id: "example".into(), depends_on: vec![],
                max_attempts: 3, timeout_seconds: 30, action,
            },
            input: json!({"user":"Ada"}),
            dependencies: json!({"step_1":{"answer":42}}),
        }
    }

    #[tokio::test]
    async fn echo_returns_literal() {
        let task = task(TaskAction::Echo { value: json!({"hi":"there"}) });
        assert_eq!(execute(&task, &http_client().unwrap(), false, &[]).await.unwrap(), json!({"hi":"there"}));
    }

    #[tokio::test]
    async fn input_returns_run_input() {
        let task = task(TaskAction::Input);
        assert_eq!(execute(&task, &http_client().unwrap(), false, &[]).await.unwrap(), json!({"user":"Ada"}));
    }

    #[tokio::test]
    async fn collect_returns_dependency_results() {
        let task = task(TaskAction::Collect);
        assert_eq!(execute(&task, &http_client().unwrap(), false, &[]).await.unwrap(), json!({"step_1":{"answer":42}}));
    }

    #[tokio::test]
    async fn sleep_returns_null() {
        let task = task(TaskAction::Sleep { milliseconds: 0 });
        assert_eq!(execute(&task, &http_client().unwrap(), false, &[]).await.unwrap(), Value::Null);
    }

    #[tokio::test]
    async fn failure_is_retryable() {
        let task = task(TaskAction::Fail { message: "test".into() });
        assert!(execute(&task, &http_client().unwrap(), false, &[]).await.unwrap_err().retryable());
    }

    #[tokio::test]
    async fn plain_http_is_rejected_by_default() {
        let task = task(TaskAction::Http {
            url: "http://example.com".into(), method: HttpMethod::Get,
            body: None, body_from_input: false,
        });
        assert!(!execute(&task, &http_client().unwrap(), false, &[]).await.unwrap_err().retryable());
    }

    #[tokio::test]
    async fn https_host_not_on_allowlist_is_rejected() {
        let task = task(TaskAction::Http {
            url: "https://example.com/api".into(), method: HttpMethod::Get,
            body: None, body_from_input: false,
        });
        assert!(!execute(&task, &http_client().unwrap(), false, &[]).await.unwrap_err().retryable());
    }

    #[tokio::test]
    async fn url_credentials_are_rejected() {
        let task = task(TaskAction::Http {
            url: "https://alice:secret@example.com".into(), method: HttpMethod::Get,
            body: None, body_from_input: false,
        });
        assert!(!execute(&task, &http_client().unwrap(), false, &[]).await.unwrap_err().retryable());
    }
}
