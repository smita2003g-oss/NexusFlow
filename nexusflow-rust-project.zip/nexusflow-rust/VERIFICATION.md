# Verification methodology and honest status

This repository was created in an environment with **no installed `rustc`, `cargo`, PostgreSQL server, Docker or outbound network access**. Consequently **no successful compilation, Rust unit test, SQL integration test, Docker build, or CI execution is claimed**. The code has not yet been proven working by execution.

## Verification level 1 — offline structural checks

Run `python3 scripts/audit.py`. It checks TOML/JSON parsing, workspace members/paths, expected source and workflow files, key SQL/worker constructs, test markers, Git provenance and counts authored Rust LOC without vendored files. Results can be written to a JSON report by `--json path`. These are static checks, not proof of Rust typechecking or runtime correctness.

## Verification level 2 — independent physical line count and Git integrity

Run `bash scripts/verify.sh`. This independently counts physical lines of `*.rs` files using `find`, `wc` and `awk`, compares them with Python's count, checks `git diff --check`, runs the static audit and reports whether Cargo exists. When Cargo is installed and `DATABASE_URL` points to PostgreSQL, add `--cargo` to run formatting, Clippy, workspace tests and release build.

Both LOC checks must agree. **Neither replaces a successful test run.** The initial Rust LOC total is far below 100,000 and no padding was added.

## Required executable verification on a Rust machine

```bash
export DATABASE_URL=postgres://nexusflow:nexusflow@localhost:5432/nexusflow_test
# Start a dedicated PostgreSQL test server first.
cargo generate-lockfile
cargo fmt --all                  # format initial AI-generated source
cargo fmt --all -- --check
cargo clippy --workspace --all-targets -- -D warnings
cargo test --workspace -- --test-threads=1
cargo build --release --workspace
docker compose up --build -d
curl -fsS http://localhost:8080/healthz
curl -fsS http://localhost:8080/readyz
```

Publish the repo to GitHub under the authorized owner's account, require reviewed PRs, and confirm real CI results. The Git commit history in the supplied bundle contains only real local commits made during initial authoring; it has no genuine GitHub PRs. A GitHub history requirement cannot be verified from this local zip alone.

## Criteria cross-check

| Requirement | Current status |
| --- | --- |
| Rust implementation | Source files present; compilation **not verified** |
| Distributed task claiming/retries | Implemented in source; integration tests written **but not executed** |
| 100,000+ lines of human-authored code | **Not met**; independently measured count is below threshold |
| Predominantly human-written | **Not met**; initial source is overwhelmingly AI-generated |
| Ownership / exclusive licensing authority | **Unknown** without user/company records |
| No AI provider already has access | **Not certifiable**, because produced through ChatGPT |
| Full original GitHub history with real PRs over time | **Not met**; no remote PRs or historical development |
| Tests, docs, CI, issue/PR templates | Files present; no executed CI in this environment |
| Double verification | Independent static/LOC passes; **not double executable verification** |

Do not submit this project as if all criteria are satisfied. Obtain human contributors, real development time and actual independent runtime evidence first.
