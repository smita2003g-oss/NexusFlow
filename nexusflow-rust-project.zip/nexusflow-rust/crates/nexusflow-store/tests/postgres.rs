//! Integration tests require DATABASE_URL and an empty/migratable PostgreSQL DB.
//! CI starts a dedicated PostgreSQL service before running these tests.

use nexusflow_core::{TaskAction, TaskDefinition, WorkflowDefinition};
use nexusflow_store::Store;
use serde_json::json;
use sqlx::PgPool;
use uuid::Uuid;

async fn setup() -> (Store, PgPool) {
    let url = std::env::var("DATABASE_URL")
        .expect("set DATABASE_URL to run PostgreSQL integration tests");
    let store = Store::connect(&url, 10).await.expect("connect database");
    store.migrate().await.expect("apply migrations");
    let pool = PgPool::connect(&url).await.expect("connect auxiliary pool");
    (store, pool)
}

fn task(id: &str, predecessors: &[&str]) -> TaskDefinition {
    TaskDefinition {
        id: id.into(),
        depends_on: predecessors.iter().map(|s| (*s).into()).collect(),
        max_attempts: 3,
        timeout_seconds: 30,
        action: TaskAction::Echo { value: json!(id) },
    }
}

async fn new_workflow(store: &Store, tasks: Vec<TaskDefinition>) -> Uuid {
    store
        .create_workflow(&WorkflowDefinition { name: "integration".into(), tasks })
        .await
        .unwrap()
        .id
}

#[tokio::test]
async fn workflow_can_be_saved_and_listed() {
    let (store, _) = setup().await;
    let id = new_workflow(&store, vec![task("single", &[])]).await;
    let record = store.get_workflow(id).await.unwrap().unwrap();
    assert_eq!(record.name, "integration");
    assert_eq!(record.definition["tasks"][0]["id"], "single");
    assert!(store.list_workflows(100).await.unwrap().iter().any(|wf| wf.id == id));
}

#[tokio::test]
async fn single_task_run_succeeds_and_is_durable() {
    let (store, _) = setup().await;
    let workflow = new_workflow(&store, vec![task("a", &[])]).await;
    let run = store.start_run(workflow, json!({"x":1}), None).await.unwrap();
    assert!(run.created);
    let claimed = store.claim("worker-a", 30).await.unwrap().unwrap();
    assert_eq!(claimed.run_id, run.run_id);
    assert_eq!(claimed.input, json!({"x":1}));
    assert_eq!(claimed.attempts, 1);
    assert!(store.succeed(&claimed, "worker-a", json!({"ok":true})).await.unwrap());
    let view = store.get_run(run.run_id).await.unwrap().unwrap();
    assert_eq!(view.run.status, "succeeded");
    assert_eq!(view.tasks.len(), 1);
    assert_eq!(view.tasks[0].result, Some(json!({"ok":true})));
    assert!(view.run.completed_at.is_some());
}

#[tokio::test]
async fn dependencies_block_until_predecessors_succeed() {
    let (store, _) = setup().await;
    let workflow = new_workflow(&store, vec![task("root", &[]), task("child", &["root"])]).await;
    let run = store.start_run(workflow, json!({}), None).await.unwrap();
    let root = store.claim("owner-a", 30).await.unwrap().unwrap();
    assert_eq!(root.node_id, "root");
    assert!(store.claim("owner-b", 30).await.unwrap().is_none());
    store.succeed(&root, "owner-a", json!(42)).await.unwrap();
    let child = store.claim("owner-b", 30).await.unwrap().unwrap();
    assert_eq!(child.node_id, "child");
    assert_eq!(child.dependencies, json!({"root":42}));
    store.succeed(&child, "owner-b", json!({"result":true})).await.unwrap();
    assert_eq!(store.get_run(run.run_id).await.unwrap().unwrap().run.status, "succeeded");
}

#[tokio::test]
async fn idempotency_key_returns_original_run() {
    let (store, _) = setup().await;
    let workflow = new_workflow(&store, vec![task("a", &[])]).await;
    let first = store.start_run(workflow, json!({"value":1}), Some("client-request-1")).await.unwrap();
    let second = store.start_run(workflow, json!({"value":2}), Some("client-request-1")).await.unwrap();
    assert!(first.created);
    assert!(!second.created);
    assert_eq!(first.run_id, second.run_id);
    let view = store.get_run(first.run_id).await.unwrap().unwrap();
    assert_eq!(view.run.input, json!({"value":1}));
    assert_eq!(view.tasks.len(), 1);
    assert!(store.cancel_run(first.run_id).await.unwrap());
}

#[tokio::test]
async fn concurrent_idempotency_requests_return_same_run() {
    let (store, _) = setup().await;
    let workflow = new_workflow(&store, vec![task("a", &[])]).await;
    let (a, b) = tokio::join!(
        store.start_run(workflow, json!(1), Some("concurrent-key")),
        store.start_run(workflow, json!(2), Some("concurrent-key"))
    );
    let a = a.unwrap();
    let b = b.unwrap();
    assert_eq!(a.run_id, b.run_id);
    assert_ne!(a.created, b.created);
    assert!(store.cancel_run(a.run_id).await.unwrap());
}

#[tokio::test]
async fn second_worker_cannot_claim_held_task() {
    let (store, _) = setup().await;
    let workflow = new_workflow(&store, vec![task("a", &[])]).await;
    let run = store.start_run(workflow, json!({}), None).await.unwrap();
    let (left, right) = tokio::join!(store.claim("owner-a", 30), store.claim("owner-b", 30));
    let count = usize::from(left.unwrap().is_some()) + usize::from(right.unwrap().is_some());
    assert_eq!(count, 1);
    assert!(store.cancel_run(run.run_id).await.unwrap());
}

#[tokio::test]
async fn stale_attempt_cannot_write_after_lease_reclaim() {
    let (store, pool) = setup().await;
    let workflow = new_workflow(&store, vec![task("a", &[])]).await;
    store.start_run(workflow, json!({}), None).await.unwrap();
    let first = store.claim("old-worker", 30).await.unwrap().unwrap();
    sqlx::query("UPDATE task_runs SET lease_expires_at = now() - INTERVAL '1 second' WHERE id = $1")
        .bind(first.id).execute(&pool).await.unwrap();
    let second = store.claim("new-worker", 30).await.unwrap().unwrap();
    assert_eq!(first.id, second.id);
    assert_eq!(second.attempts, 2);
    assert!(!store.succeed(&first, "old-worker", json!("stale")).await.unwrap());
    assert!(store.succeed(&second, "new-worker", json!("current")).await.unwrap());
}

#[tokio::test]
async fn failure_retries_then_fails_run() {
    let (store, _) = setup().await;
    let workflow = new_workflow(&store, vec![task("a", &[])]).await;
    let run = store.start_run(workflow, json!({}), None).await.unwrap();
    let first = store.claim("owner-a", 30).await.unwrap().unwrap();
    assert!(store.fail(&first, "owner-a", "temporary", true, 0).await.unwrap());
    let second = store.claim("owner-b", 30).await.unwrap().unwrap();
    assert_eq!(second.attempts, 2);
    assert!(store.fail(&second, "owner-b", "permanent", false, 0).await.unwrap());
    let view = store.get_run(run.run_id).await.unwrap().unwrap();
    assert_eq!(view.run.status, "failed");
    assert_eq!(view.tasks[0].status, "failed");
    assert_eq!(view.tasks[0].attempts, 2);
}

#[tokio::test]
async fn final_expired_lease_is_reaped() {
    let (store, pool) = setup().await;
    let mut once = task("a", &[]);
    once.max_attempts = 1;
    let workflow = new_workflow(&store, vec![once]).await;
    let run = store.start_run(workflow, json!({}), None).await.unwrap();
    let claimed = store.claim("owner", 30).await.unwrap().unwrap();
    sqlx::query("UPDATE task_runs SET lease_expires_at = now() - INTERVAL '1 second' WHERE id = $1")
        .bind(claimed.id).execute(&pool).await.unwrap();
    assert!(store.claim("other", 30).await.unwrap().is_none());
    assert!(store.reap_exhausted_leases().await.unwrap() >= 1);
    let view = store.get_run(run.run_id).await.unwrap().unwrap();
    assert_eq!(view.run.status, "failed");
    assert_eq!(view.tasks[0].status, "failed");
}

#[tokio::test]
async fn cancel_prevents_task_completion() {
    let (store, _) = setup().await;
    let workflow = new_workflow(&store, vec![task("a", &[])]).await;
    let run = store.start_run(workflow, json!({}), None).await.unwrap();
    let claimed = store.claim("owner", 30).await.unwrap().unwrap();
    assert!(store.cancel_run(run.run_id).await.unwrap());
    assert!(!store.cancel_run(run.run_id).await.unwrap());
    assert!(!store.heartbeat(&claimed, "owner", 30).await.unwrap());
    assert!(!store.succeed(&claimed, "owner", json!(1)).await.unwrap());
    assert_eq!(store.get_run(run.run_id).await.unwrap().unwrap().run.status, "canceled");
}

#[tokio::test]
async fn parallel_terminal_completions_do_not_lose_success_status() {
    let (store, _) = setup().await;
    let workflow = new_workflow(&store, vec![task("a", &[]), task("b", &[])]).await;
    let run = store.start_run(workflow, json!({}), None).await.unwrap();
    let first = store.claim("owner-a", 30).await.unwrap().unwrap();
    let second = store.claim("owner-b", 30).await.unwrap().unwrap();
    assert_ne!(first.id, second.id);
    let (a, b) = tokio::join!(
        store.succeed(&first, "owner-a", json!(true)),
        store.succeed(&second, "owner-b", json!(true)),
    );
    assert!(a.unwrap());
    assert!(b.unwrap());
    assert_eq!(store.get_run(run.run_id).await.unwrap().unwrap().run.status, "succeeded");
}

#[tokio::test]
async fn missing_run_returns_none() {
    let (store, _) = setup().await;
    assert!(store.get_run(Uuid::new_v4()).await.unwrap().is_none());
}
