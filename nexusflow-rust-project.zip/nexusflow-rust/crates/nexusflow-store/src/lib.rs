//! PostgreSQL implementation of the durable workflow scheduler.
//!
//! Claims use `FOR UPDATE SKIP LOCKED` and compare-and-swap fencing
//! (worker ID + attempt number). Completing a task locks its workflow run,
//! serializing concurrent final-task completions.

use anyhow::{anyhow, Context, Result};
use chrono::{DateTime, Utc};
use nexusflow_core::{TaskDefinition, WorkflowDefinition};
use serde::Serialize;
use serde_json::{Map, Value};
use sqlx::{postgres::PgPoolOptions, PgPool};
use std::collections::HashMap;
use uuid::Uuid;

#[derive(Debug, Clone)]
pub struct Store {
    pool: PgPool,
}

#[derive(Debug, Clone, Serialize, sqlx::FromRow)]
pub struct WorkflowRecord {
    pub id: Uuid,
    pub name: String,
    pub definition: Value,
    pub created_at: DateTime<Utc>,
}

#[derive(Debug, Clone, Serialize, sqlx::FromRow)]
pub struct RunRecord {
    pub id: Uuid,
    pub workflow_id: Uuid,
    pub status: String,
    pub input: Value,
    pub created_at: DateTime<Utc>,
    pub updated_at: DateTime<Utc>,
    pub completed_at: Option<DateTime<Utc>>,
}

#[derive(Debug, Clone, Serialize, sqlx::FromRow)]
pub struct TaskRecord {
    pub id: Uuid,
    pub run_id: Uuid,
    pub node_id: String,
    pub status: String,
    pub attempts: i32,
    pub max_attempts: i32,
    pub next_attempt_at: DateTime<Utc>,
    pub lease_owner: Option<String>,
    pub lease_expires_at: Option<DateTime<Utc>>,
    pub result: Option<Value>,
    pub error: Option<String>,
    pub started_at: Option<DateTime<Utc>>,
    pub finished_at: Option<DateTime<Utc>>,
}

#[derive(Debug, Clone, Serialize)]
pub struct RunView {
    #[serde(flatten)]
    pub run: RunRecord,
    pub tasks: Vec<TaskRecord>,
}

#[derive(Debug, Clone, Copy, Serialize)]
pub struct StartResult {
    pub run_id: Uuid,
    pub created: bool,
}

#[derive(Debug, Clone)]
pub struct ClaimedTask {
    pub id: Uuid,
    pub run_id: Uuid,
    pub node_id: String,
    pub attempts: i32,
    pub max_attempts: i32,
    pub definition: TaskDefinition,
    pub input: Value,
    pub dependencies: Value,
}

#[derive(Debug, sqlx::FromRow)]
struct ClaimRow {
    id: Uuid,
    run_id: Uuid,
    node_id: String,
    attempts: i32,
    max_attempts: i32,
}

impl Store {
    pub async fn connect(database_url: &str, max_connections: u32) -> Result<Self> {
        let pool = PgPoolOptions::new()
            .max_connections(max_connections)
            .connect(database_url)
            .await
            .context("connect to PostgreSQL")?;
        Ok(Self { pool })
    }

    pub fn from_pool(pool: PgPool) -> Self {
        Self { pool }
    }

    pub async fn migrate(&self) -> Result<()> {
        sqlx::migrate!("../../migrations")
            .run(&self.pool)
            .await
            .context("run SQL migrations")?;
        Ok(())
    }

    pub async fn ping(&self) -> Result<()> {
        sqlx::query("SELECT 1")
            .execute(&self.pool)
            .await
            .context("ping PostgreSQL")?;
        Ok(())
    }

    pub async fn create_workflow(&self, definition: &WorkflowDefinition) -> Result<WorkflowRecord> {
        definition.validate().context("invalid workflow")?;
        let id = Uuid::new_v4();
        let value = serde_json::to_value(definition)?;
        let row = sqlx::query_as::<_, WorkflowRecord>(
            "INSERT INTO workflow_definitions (id, name, definition) \
             VALUES ($1, $2, $3) RETURNING id, name, definition, created_at",
        )
        .bind(id)
        .bind(&definition.name)
        .bind(value)
        .fetch_one(&self.pool)
        .await?;
        Ok(row)
    }

    pub async fn get_workflow(&self, id: Uuid) -> Result<Option<WorkflowRecord>> {
        Ok(sqlx::query_as::<_, WorkflowRecord>(
            "SELECT id, name, definition, created_at FROM workflow_definitions WHERE id = $1",
        )
        .bind(id)
        .fetch_optional(&self.pool)
        .await?)
    }

    pub async fn list_workflows(&self, limit: i64) -> Result<Vec<WorkflowRecord>> {
        Ok(sqlx::query_as::<_, WorkflowRecord>(
            "SELECT id, name, definition, created_at FROM workflow_definitions \
             ORDER BY created_at DESC, id DESC LIMIT $1",
        )
        .bind(limit.clamp(1, 100))
        .fetch_all(&self.pool)
        .await?)
    }

    /// Atomically create a run, all its tasks and dependency edges.
    /// A repeated (workflow, idempotency_key) returns the original run.
    pub async fn start_run(
        &self,
        workflow_id: Uuid,
        input: Value,
        idempotency_key: Option<&str>,
    ) -> Result<StartResult> {
        if let Some(key) = idempotency_key {
            anyhow::ensure!(
                !key.is_empty() && key.len() <= 200,
                "idempotency key must be 1..=200 bytes"
            );
        }
        let workflow = self
            .get_workflow(workflow_id)
            .await?
            .ok_or_else(|| anyhow!("workflow not found"))?;
        let definition: WorkflowDefinition = serde_json::from_value(workflow.definition)?;
        definition.validate()?;

        let mut tx = self.pool.begin().await?;
        let run_id = Uuid::new_v4();
        let inserted = sqlx::query_scalar::<_, Uuid>(
            "INSERT INTO workflow_runs (id, workflow_id, input, idempotency_key) \
             VALUES ($1, $2, $3, $4) \
             ON CONFLICT (workflow_id, idempotency_key) DO NOTHING RETURNING id",
        )
        .bind(run_id)
        .bind(workflow_id)
        .bind(input)
        .bind(idempotency_key)
        .fetch_optional(&mut *tx)
        .await?;

        if inserted.is_none() {
            let existing = sqlx::query_scalar::<_, Uuid>(
                "SELECT id FROM workflow_runs WHERE workflow_id = $1 AND idempotency_key = $2",
            )
            .bind(workflow_id)
            .bind(idempotency_key)
            .fetch_one(&mut *tx)
            .await?;
            tx.commit().await?;
            return Ok(StartResult {
                run_id: existing,
                created: false,
            });
        }

        let mut task_ids = HashMap::with_capacity(definition.tasks.len());
        for task in &definition.tasks {
            let task_id = Uuid::new_v4();
            sqlx::query(
                "INSERT INTO task_runs (id, run_id, node_id, max_attempts) VALUES ($1, $2, $3, $4)",
            )
            .bind(task_id)
            .bind(run_id)
            .bind(&task.id)
            .bind(task.max_attempts)
            .execute(&mut *tx)
            .await?;
            task_ids.insert(task.id.as_str(), task_id);
        }
        for task in &definition.tasks {
            let task_id = task_ids[task.id.as_str()];
            for predecessor in &task.depends_on {
                sqlx::query(
                    "INSERT INTO task_dependencies (task_id, depends_on_node_id) VALUES ($1, $2)",
                )
                .bind(task_id)
                .bind(predecessor)
                .execute(&mut *tx)
                .await?;
            }
        }
        tx.commit().await?;
        Ok(StartResult {
            run_id,
            created: true,
        })
    }

    pub async fn get_run(&self, id: Uuid) -> Result<Option<RunView>> {
        let run = sqlx::query_as::<_, RunRecord>(
            "SELECT id, workflow_id, status, input, created_at, updated_at, completed_at \
             FROM workflow_runs WHERE id = $1",
        )
        .bind(id)
        .fetch_optional(&self.pool)
        .await?;
        let Some(run) = run else {
            return Ok(None);
        };
        let tasks = sqlx::query_as::<_, TaskRecord>(
            "SELECT id, run_id, node_id, status, attempts, max_attempts, next_attempt_at, \
             lease_owner, lease_expires_at, result, error, started_at, finished_at \
             FROM task_runs WHERE run_id = $1 ORDER BY node_id",
        )
        .bind(id)
        .fetch_all(&self.pool)
        .await?;
        Ok(Some(RunView { run, tasks }))
    }

    /// Claim the next ready task. Candidate tasks are row-locked and skipped
    /// when another worker is already claiming them. Lease reclaims increment
    /// attempts; the attempt is also the fencing token for final writes.
    pub async fn claim(&self, worker_id: &str, lease_seconds: i64) -> Result<Option<ClaimedTask>> {
        anyhow::ensure!(lease_seconds >= 10, "lease must be at least 10 seconds");
        let claimed = sqlx::query_as::<_, ClaimRow>(
            r#"
            WITH candidate AS (
                SELECT t.id
                FROM task_runs t
                JOIN workflow_runs r ON r.id = t.run_id
                WHERE r.status = 'running'
                  AND t.attempts < t.max_attempts
                  AND (
                    (t.status IN ('pending', 'retry_wait') AND t.next_attempt_at <= now())
                    OR (t.status = 'running' AND t.lease_expires_at < now())
                  )
                  AND NOT EXISTS (
                    SELECT 1 FROM task_dependencies d
                    JOIN task_runs predecessor
                      ON predecessor.run_id = t.run_id
                     AND predecessor.node_id = d.depends_on_node_id
                    WHERE d.task_id = t.id AND predecessor.status <> 'succeeded'
                  )
                ORDER BY t.next_attempt_at, t.created_at, t.id
                FOR UPDATE OF t SKIP LOCKED
                LIMIT 1
            )
            UPDATE task_runs t
               SET status = 'running',
                   attempts = t.attempts + 1,
                   lease_owner = $1,
                   lease_expires_at = now() + ($2::bigint * INTERVAL '1 second'),
                   started_at = COALESCE(t.started_at, now()),
                   updated_at = now(),
                   error = NULL
              FROM candidate
             WHERE t.id = candidate.id
            RETURNING t.id, t.run_id, t.node_id, t.attempts, t.max_attempts
            "#,
        )
        .bind(worker_id)
        .bind(lease_seconds)
        .fetch_optional(&self.pool)
        .await?;

        let Some(claimed) = claimed else {
            return Ok(None);
        };
        let (definition_value, input): (Value, Value) = sqlx::query_as(
            "SELECT d.definition, r.input FROM workflow_runs r \
             JOIN workflow_definitions d ON d.id = r.workflow_id WHERE r.id = $1",
        )
        .bind(claimed.run_id)
        .fetch_one(&self.pool)
        .await?;
        let workflow: WorkflowDefinition = serde_json::from_value(definition_value)?;
        let definition = workflow
            .task(&claimed.node_id)
            .cloned()
            .ok_or_else(|| anyhow!("persisted task missing from definition"))?;
        let dependencies: Vec<(String, Option<Value>)> = sqlx::query_as(
            "SELECT d.depends_on_node_id, t.result FROM task_dependencies d \
             JOIN task_runs t ON t.run_id = $1 AND t.node_id = d.depends_on_node_id \
             WHERE d.task_id = $2 ORDER BY d.depends_on_node_id",
        )
        .bind(claimed.run_id)
        .bind(claimed.id)
        .fetch_all(&self.pool)
        .await?;
        let dependency_object: Map<String, Value> = dependencies
            .into_iter()
            .map(|(key, value)| (key, value.unwrap_or(Value::Null)))
            .collect();
        Ok(Some(ClaimedTask {
            id: claimed.id,
            run_id: claimed.run_id,
            node_id: claimed.node_id,
            attempts: claimed.attempts,
            max_attempts: claimed.max_attempts,
            definition,
            input,
            dependencies: Value::Object(dependency_object),
        }))
    }

    pub async fn heartbeat(&self, task: &ClaimedTask, worker_id: &str, lease_seconds: i64) -> Result<bool> {
        let result = sqlx::query(
            "UPDATE task_runs t SET lease_expires_at = now() + ($4::bigint * INTERVAL '1 second'), \
             updated_at = now() WHERE t.id = $1 AND t.lease_owner = $2 \
             AND t.attempts = $3 AND t.status = 'running' \
             AND t.lease_expires_at > now() \
             AND EXISTS (SELECT 1 FROM workflow_runs r WHERE r.id = t.run_id AND r.status = 'running')",
        )
        .bind(task.id)
        .bind(worker_id)
        .bind(task.attempts)
        .bind(lease_seconds)
        .execute(&self.pool)
        .await?;
        Ok(result.rows_affected() == 1)
    }

    pub async fn succeed(&self, task: &ClaimedTask, worker_id: &str, result: Value) -> Result<bool> {
        let mut tx = self.pool.begin().await?;
        // All successful/final transitions within a run lock this row first.
        sqlx::query("SELECT id FROM workflow_runs WHERE id = $1 FOR UPDATE")
            .bind(task.run_id)
            .fetch_one(&mut *tx)
            .await?;
        let updated = sqlx::query_scalar::<_, Uuid>(
            "UPDATE task_runs SET status = 'succeeded', result = $4, \
             lease_owner = NULL, lease_expires_at = NULL, error = NULL, \
             updated_at = now(), finished_at = now() \
             WHERE id = $1 AND lease_owner = $2 AND attempts = $3 \
             AND status = 'running' AND lease_expires_at > now() \
             AND EXISTS (SELECT 1 FROM workflow_runs WHERE id = $5 AND status = 'running') \
             RETURNING id",
        )
        .bind(task.id)
        .bind(worker_id)
        .bind(task.attempts)
        .bind(result)
        .bind(task.run_id)
        .fetch_optional(&mut *tx)
        .await?;
        if updated.is_none() {
            tx.rollback().await?;
            return Ok(false);
        }
        sqlx::query(
            "UPDATE workflow_runs SET status = 'succeeded', completed_at = now(), \
             updated_at = now() WHERE id = $1 AND status = 'running' AND NOT EXISTS \
             (SELECT 1 FROM task_runs WHERE run_id = $1 AND status <> 'succeeded')",
        )
        .bind(task.run_id)
        .execute(&mut *tx)
        .await?;
        tx.commit().await?;
        Ok(true)
    }

    /// Persist failure, retrying when permitted. A permanent failure makes
    /// the whole workflow run terminal; no new tasks are then claimed.
    pub async fn fail(
        &self,
        task: &ClaimedTask,
        worker_id: &str,
        error: &str,
        retryable: bool,
        retry_delay_seconds: i64,
    ) -> Result<bool> {
        let mut tx = self.pool.begin().await?;
        sqlx::query("SELECT id FROM workflow_runs WHERE id = $1 FOR UPDATE")
            .bind(task.run_id)
            .fetch_one(&mut *tx)
            .await?;
        let retry = retryable && task.attempts < task.max_attempts;
        let next_status = if retry { "retry_wait" } else { "failed" };
        let updated = sqlx::query_scalar::<_, Uuid>(
            "UPDATE task_runs SET status = $4, error = $5, \
             next_attempt_at = now() + ($6::bigint * INTERVAL '1 second'), \
             lease_owner = NULL, lease_expires_at = NULL, updated_at = now(), \
             finished_at = CASE WHEN $4 = 'failed' THEN now() ELSE NULL END \
             WHERE id = $1 AND lease_owner = $2 AND attempts = $3 \
             AND status = 'running' AND lease_expires_at > now() \
             AND EXISTS (SELECT 1 FROM workflow_runs WHERE id = $7 AND status = 'running') \
             RETURNING id",
        )
        .bind(task.id)
        .bind(worker_id)
        .bind(task.attempts)
        .bind(next_status)
        .bind(error.chars().take(4096).collect::<String>())
        .bind(retry_delay_seconds.clamp(0, 3600))
        .bind(task.run_id)
        .fetch_optional(&mut *tx)
        .await?;
        if updated.is_none() {
            tx.rollback().await?;
            return Ok(false);
        }
        if !retry {
            sqlx::query(
                "UPDATE workflow_runs SET status = 'failed', completed_at = now(), \
                 updated_at = now() WHERE id = $1 AND status = 'running'",
            )
            .bind(task.run_id)
            .execute(&mut *tx)
            .await?;
        }
        tx.commit().await?;
        Ok(true)
    }

    /// Expired final attempts cannot be claimed again. Lock workflow rows
    /// before their task rows (same order as `succeed` and `fail`) and persist
    /// the failed task/run transition in ONE transaction. A crash cannot
    /// leave a failed task inside a permanently running workflow.
    pub async fn reap_exhausted_leases(&self) -> Result<usize> {
        let mut tx = self.pool.begin().await?;
        let candidate_runs: Vec<Uuid> = sqlx::query_scalar(
            r#"
            SELECT r.id FROM workflow_runs r
            WHERE r.status = 'running' AND EXISTS (
                SELECT 1 FROM task_runs t
                WHERE t.run_id = r.id AND t.status = 'running'
                  AND t.lease_expires_at < now() AND t.attempts >= t.max_attempts
            )
            ORDER BY r.created_at
            FOR UPDATE OF r SKIP LOCKED
            LIMIT 100
            "#,
        )
        .fetch_all(&mut *tx)
        .await?;
        if candidate_runs.is_empty() {
            tx.commit().await?;
            return Ok(0);
        }
        let failed_runs: Vec<Uuid> = sqlx::query_scalar(
            r#"
            UPDATE task_runs SET status = 'failed',
                error = 'lease expired at maximum attempts',
                lease_owner = NULL, lease_expires_at = NULL,
                updated_at = now(), finished_at = now()
            WHERE run_id = ANY($1::uuid[]) AND status = 'running'
              AND lease_expires_at < now() AND attempts >= max_attempts
            RETURNING run_id
            "#,
        )
        .bind(&candidate_runs)
        .fetch_all(&mut *tx)
        .await?;
        let distinct: std::collections::HashSet<Uuid> = failed_runs.into_iter().collect();
        if !distinct.is_empty() {
            let run_ids: Vec<Uuid> = distinct.iter().copied().collect();
            sqlx::query(
                "UPDATE workflow_runs SET status = 'failed', completed_at = now(), \
                 updated_at = now() WHERE id = ANY($1::uuid[]) AND status = 'running'",
            )
            .bind(&run_ids)
            .execute(&mut *tx)
            .await?;
        }
        tx.commit().await?;
        Ok(distinct.len())
    }

    pub async fn cancel_run(&self, run_id: Uuid) -> Result<bool> {
        let mut tx = self.pool.begin().await?;
        let updated = sqlx::query_scalar::<_, Uuid>(
            "UPDATE workflow_runs SET status = 'canceled', updated_at = now(), \
             completed_at = now() WHERE id = $1 AND status = 'running' RETURNING id",
        )
        .bind(run_id)
        .fetch_optional(&mut *tx)
        .await?;
        if updated.is_some() {
            sqlx::query(
                "UPDATE task_runs SET status = 'canceled', updated_at = now(), \
                 lease_owner = NULL, lease_expires_at = NULL, finished_at = now() \
                 WHERE run_id = $1 AND status IN ('pending', 'running', 'retry_wait')",
            )
            .bind(run_id)
            .execute(&mut *tx)
            .await?;
        }
        tx.commit().await?;
        Ok(updated.is_some())
    }
}
