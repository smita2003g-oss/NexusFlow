//! Validated workflow definitions and pure scheduling rules.
//!
//! A workflow is a directed acyclic graph. Every task runs at least once when
//! its predecessors succeed; task actions must tolerate retries.

use serde::{Deserialize, Serialize};
use serde_json::Value;
use std::collections::{HashMap, HashSet, VecDeque};
use thiserror::Error;
use url::Url;

pub const MAX_TASKS: usize = 256;
pub const MAX_DEPENDENCIES: usize = 32;
pub const MAX_ATTEMPTS: i32 = 20;
pub const MAX_TIMEOUT_SECONDS: u32 = 3_600;

#[derive(Debug, Clone, PartialEq, Serialize, Deserialize)]
#[serde(deny_unknown_fields)]
pub struct WorkflowDefinition {
    pub name: String,
    pub tasks: Vec<TaskDefinition>,
}

#[derive(Debug, Clone, PartialEq, Serialize, Deserialize)]
#[serde(deny_unknown_fields)]
pub struct TaskDefinition {
    pub id: String,
    #[serde(default)]
    pub depends_on: Vec<String>,
    #[serde(default = "default_attempts")]
    pub max_attempts: i32,
    #[serde(default = "default_timeout")]
    pub timeout_seconds: u32,
    pub action: TaskAction,
}

const fn default_attempts() -> i32 {
    3
}

const fn default_timeout() -> u32 {
    30
}

#[derive(Debug, Clone, PartialEq, Serialize, Deserialize)]
#[serde(tag = "type", rename_all = "snake_case", deny_unknown_fields)]
pub enum TaskAction {
    /// Return a literal JSON value.
    Echo { value: Value },
    /// Return workflow input passed at run creation.
    Input,
    /// Return an object keyed by predecessor task ID, with each result.
    Collect,
    /// Wait before succeeding. Useful for workflow demonstrations.
    Sleep { milliseconds: u64 },
    /// Execute an outbound HTTP request (workers must have restricted egress).
    Http {
        url: String,
        #[serde(default)]
        method: HttpMethod,
        #[serde(default)]
        body: Option<Value>,
        #[serde(default)]
        body_from_input: bool,
    },
    /// Intentional failure for testing retry / failure behavior.
    Fail { message: String },
}

#[derive(Debug, Clone, Copy, Default, PartialEq, Eq, Serialize, Deserialize)]
#[serde(rename_all = "UPPERCASE")]
pub enum HttpMethod {
    #[default]
    Get,
    Post,
    Put,
    Patch,
}

#[derive(Debug, Error, PartialEq, Eq)]
pub enum ValidationError {
    #[error("workflow name must have 1..=100 non-whitespace characters")]
    Name,
    #[error("workflow must contain between 1 and 256 tasks")]
    TaskCount,
    #[error("invalid task ID '{0}': use 1..=64 letters, digits, '-' or '_'")]
    TaskId(String),
    #[error("duplicate task ID '{0}'")]
    DuplicateTask(String),
    #[error("task '{0}' has too many dependencies")]
    TooManyDependencies(String),
    #[error("task '{task}' depends on missing task '{dependency}'")]
    UnknownDependency { task: String, dependency: String },
    #[error("task '{0}' depends on itself")]
    SelfDependency(String),
    #[error("task '{task}' repeats dependency '{dependency}'")]
    DuplicateDependency { task: String, dependency: String },
    #[error("task '{0}' has an invalid max_attempts")]
    Attempts(String),
    #[error("task '{0}' has an invalid timeout_seconds")]
    Timeout(String),
    #[error("task '{0}' has a sleep duration beyond one hour")]
    Sleep(String),
    #[error("task '{0}' has an invalid HTTP URL (http/https with no credentials required)")]
    HttpUrl(String),
    #[error("task '{0}' combines body and body_from_input")]
    HttpBody(String),
    #[error("workflow has a dependency cycle")]
    Cycle,
}

impl WorkflowDefinition {
    /// Validate shape, limits, references and DAG acyclicity.
    pub fn validate(&self) -> Result<(), ValidationError> {
        let trimmed = self.name.trim();
        if trimmed.is_empty() || trimmed.chars().count() > 100 {
            return Err(ValidationError::Name);
        }
        if self.tasks.is_empty() || self.tasks.len() > MAX_TASKS {
            return Err(ValidationError::TaskCount);
        }

        let mut ids = HashSet::with_capacity(self.tasks.len());
        for task in &self.tasks {
            let valid_id = !task.id.is_empty()
                && task.id.len() <= 64
                && task
                    .id
                    .chars()
                    .all(|ch| ch.is_ascii_alphanumeric() || ch == '_' || ch == '-');
            if !valid_id {
                return Err(ValidationError::TaskId(task.id.clone()));
            }
            if !ids.insert(task.id.as_str()) {
                return Err(ValidationError::DuplicateTask(task.id.clone()));
            }
            if task.max_attempts < 1 || task.max_attempts > MAX_ATTEMPTS {
                return Err(ValidationError::Attempts(task.id.clone()));
            }
            if task.timeout_seconds == 0 || task.timeout_seconds > MAX_TIMEOUT_SECONDS {
                return Err(ValidationError::Timeout(task.id.clone()));
            }
            if task.depends_on.len() > MAX_DEPENDENCIES {
                return Err(ValidationError::TooManyDependencies(task.id.clone()));
            }
            match &task.action {
                TaskAction::Sleep { milliseconds } if *milliseconds > 3_600_000 => {
                    return Err(ValidationError::Sleep(task.id.clone()));
                }
                TaskAction::Http {
                    url,
                    body,
                    body_from_input,
                    ..
                } => {
                    let valid = Url::parse(url).is_ok_and(|parsed| {
                        matches!(parsed.scheme(), "http" | "https")
                            && parsed.has_host()
                            && parsed.username().is_empty()
                            && parsed.password().is_none()
                    });
                    if !valid {
                        return Err(ValidationError::HttpUrl(task.id.clone()));
                    }
                    if *body_from_input && body.is_some() {
                        return Err(ValidationError::HttpBody(task.id.clone()));
                    }
                }
                _ => {}
            }
        }

        let mut indegree: HashMap<&str, usize> = self
            .tasks
            .iter()
            .map(|task| (task.id.as_str(), 0))
            .collect();
        let mut children: HashMap<&str, Vec<&str>> = HashMap::new();
        for task in &self.tasks {
            let mut seen = HashSet::new();
            for dependency in &task.depends_on {
                if dependency == &task.id {
                    return Err(ValidationError::SelfDependency(task.id.clone()));
                }
                if !ids.contains(dependency.as_str()) {
                    return Err(ValidationError::UnknownDependency {
                        task: task.id.clone(),
                        dependency: dependency.clone(),
                    });
                }
                if !seen.insert(dependency.as_str()) {
                    return Err(ValidationError::DuplicateDependency {
                        task: task.id.clone(),
                        dependency: dependency.clone(),
                    });
                }
                *indegree.get_mut(task.id.as_str()).expect("known task") += 1;
                children
                    .entry(dependency.as_str())
                    .or_default()
                    .push(task.id.as_str());
            }
        }

        let mut queue: VecDeque<&str> = indegree
            .iter()
            .filter(|(_, degree)| **degree == 0)
            .map(|(id, _)| *id)
            .collect();
        let mut visited = 0;
        while let Some(id) = queue.pop_front() {
            visited += 1;
            if let Some(next) = children.get(id) {
                for child in next {
                    let degree = indegree.get_mut(child).expect("known child");
                    *degree -= 1;
                    if *degree == 0 {
                        queue.push_back(child);
                    }
                }
            }
        }
        if visited == self.tasks.len() {
            Ok(())
        } else {
            Err(ValidationError::Cycle)
        }
    }

    pub fn task(&self, id: &str) -> Option<&TaskDefinition> {
        self.tasks.iter().find(|task| task.id == id)
    }
}

/// Seconds to wait after the given failed attempt (1-based), capped at 5 min.
pub fn retry_delay_seconds(attempt: i32) -> i64 {
    let shift = attempt.clamp(0, 8) as u32;
    (1_i64 << shift).min(300)
}

#[cfg(test)]
mod tests {
    use super::*;
    use serde_json::json;

    fn task(id: &str, dependencies: &[&str]) -> TaskDefinition {
        TaskDefinition {
            id: id.to_owned(),
            depends_on: dependencies.iter().map(|v| (*v).to_owned()).collect(),
            max_attempts: 3,
            timeout_seconds: 30,
            action: TaskAction::Echo { value: json!(1) },
        }
    }

    fn workflow(tasks: Vec<TaskDefinition>) -> WorkflowDefinition {
        WorkflowDefinition {
            name: "workflow".to_owned(),
            tasks,
        }
    }

    #[test]
    fn valid_linear_graph() {
        assert!(workflow(vec![task("a", &[]), task("b", &["a"])]).validate().is_ok());
    }

    #[test]
    fn valid_diamond_graph() {
        assert!(workflow(vec![
            task("a", &[]), task("b", &["a"]),
            task("c", &["a"]), task("d", &["b", "c"]),
        ])
        .validate()
        .is_ok());
    }

    #[test]
    fn rejects_cycle() {
        let graph = workflow(vec![task("a", &["c"]), task("b", &["a"]), task("c", &["b"])]);
        assert_eq!(graph.validate(), Err(ValidationError::Cycle));
    }

    #[test]
    fn rejects_self_dependency() {
        assert_eq!(
            workflow(vec![task("a", &["a"])]).validate(),
            Err(ValidationError::SelfDependency("a".to_owned()))
        );
    }

    #[test]
    fn rejects_unknown_dependency() {
        assert!(matches!(
            workflow(vec![task("a", &["missing"])]).validate(),
            Err(ValidationError::UnknownDependency { .. })
        ));
    }

    #[test]
    fn rejects_duplicate_id() {
        assert!(matches!(
            workflow(vec![task("a", &[]), task("a", &[])]).validate(),
            Err(ValidationError::DuplicateTask(_))
        ));
    }

    #[test]
    fn rejects_duplicate_edge() {
        assert!(matches!(
            workflow(vec![task("a", &[]), task("b", &["a", "a"])]).validate(),
            Err(ValidationError::DuplicateDependency { .. })
        ));
    }

    #[test]
    fn rejects_bad_ids() {
        for bad in ["", "spaces not ok", "!", "ä"] {
            assert!(matches!(
                workflow(vec![task(bad, &[])]).validate(),
                Err(ValidationError::TaskId(_))
            ));
        }
    }

    #[test]
    fn rejects_empty_tasks() {
        assert_eq!(workflow(vec![]).validate(), Err(ValidationError::TaskCount));
    }

    #[test]
    fn rejects_blank_name() {
        let mut graph = workflow(vec![task("a", &[])]);
        graph.name = "  ".to_owned();
        assert_eq!(graph.validate(), Err(ValidationError::Name));
    }

    #[test]
    fn rejects_attempts_and_timeout() {
        let mut node = task("a", &[]);
        node.max_attempts = 0;
        assert!(matches!(
            workflow(vec![node.clone()]).validate(),
            Err(ValidationError::Attempts(_))
        ));
        node.max_attempts = 1;
        node.timeout_seconds = 0;
        assert!(matches!(
            workflow(vec![node]).validate(),
            Err(ValidationError::Timeout(_))
        ));
    }

    #[test]
    fn rejects_sleep_over_limit() {
        let mut node = task("a", &[]);
        node.action = TaskAction::Sleep { milliseconds: 3_600_001 };
        assert!(matches!(
            workflow(vec![node]).validate(),
            Err(ValidationError::Sleep(_))
        ));
    }

    #[test]
    fn rejects_invalid_http_urls() {
        for url in ["file:///etc/passwd", "http://user:pass@example.com", "bad", "ftp://x"] {
            let mut node = task("a", &[]);
            node.action = TaskAction::Http {
                url: url.into(), method: HttpMethod::Get,
                body: None, body_from_input: false,
            };
            assert!(matches!(
                workflow(vec![node]).validate(),
                Err(ValidationError::HttpUrl(_))
            ));
        }
    }

    #[test]
    fn rejects_conflicting_http_bodies() {
        let mut node = task("a", &[]);
        node.action = TaskAction::Http {
            url: "https://example.com".into(), method: HttpMethod::Post,
            body: Some(json!({"x":1})), body_from_input: true,
        };
        assert!(matches!(
            workflow(vec![node]).validate(),
            Err(ValidationError::HttpBody(_))
        ));
    }

    #[test]
    fn json_round_trip() {
        let data = workflow(vec![task("a", &[])]);
        let value = serde_json::to_value(&data).expect("serialize");
        let decoded: WorkflowDefinition = serde_json::from_value(value).expect("deserialize");
        assert_eq!(data, decoded);
    }

    #[test]
    fn retry_delay_is_capped() {
        assert_eq!(retry_delay_seconds(1), 2);
        assert_eq!(retry_delay_seconds(3), 8);
        assert_eq!(retry_delay_seconds(20), 256);
    }

    #[test]
    fn rejects_unknown_fields() {
        let value = json!({
            "name":"x","tasks":[{"id":"a","action":{"type":"input"},"unknown":"y"}]
        });
        assert!(serde_json::from_value::<WorkflowDefinition>(value).is_err());
    }

    #[test]
    fn supports_input_and_collect_actions() {
        let data = workflow(vec![
            TaskDefinition { action: TaskAction::Input, ..task("a", &[]) },
            TaskDefinition { action: TaskAction::Collect, ..task("b", &["a"]) },
        ]);
        assert!(data.validate().is_ok());
    }
}
