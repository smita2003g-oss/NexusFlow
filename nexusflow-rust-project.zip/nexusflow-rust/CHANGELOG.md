# Changelog

## Unreleased — experimental initial implementation (2026-10-30)

- Added original Rust source scaffold with DAG validation, PostgreSQL job claims, task state transitions, fencing and retries.
- Added API and worker binaries, HTTPS/webhook host allowlisting, workflow examples and Python smoke demo.
- Added SQL schema migrations, unit/integration tests, CI, Docker Compose and architectural decisions.
- Added explicit provenance and verification limitations: compilation/tests not run locally; no 100,000 LOC or human-majority claim.

This is **not a published version or evidence of deployment**. Future changelog entries should reflect real, reviewed changes and releases.
