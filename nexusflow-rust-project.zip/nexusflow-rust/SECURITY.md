# Security policy

This is an experimental project. **Do not expose it to the public Internet or give untrusted users access to run arbitrary workflows.**

## Supported versions

No production/security-supported releases exist yet.

## Reporting vulnerabilities

When hosted on GitHub, use the repository's private **Report a vulnerability** / Security Advisory mechanism, or contact the project maintainer privately. Do not include live credentials, secrets, or exploit payloads in a public issue.

## Known security gaps

- Shared API bearer token instead of short-lived authentication and fine-grained permissions.
- HTTP action URLs are restricted to exact allowed hostnames, but allowed DNS names may resolve to internal addresses (SSRF). Deploy workers in a strictly isolated network and implement a resolution-aware private-IP rejection policy before enabling untrusted users.
- No built-in tenant isolation, request quotas, encryption at rest, secrets manager, per-task resource quotas, or comprehensive audit logging.
- HTTP requests may leak user data to configured endpoints, and `input` / `echo` can retain sensitive JSON indefinitely.
- API listeners need HTTPS/TLS termination in any non-local environment. Default Docker credentials are for local demonstration only.
- Retry logic can repeat non-idempotent side effects. The emitted `Idempotency-Key` requires receiver-side enforcement.
- Pin exact build dependencies and base image digests before production use.

See `docs/architecture.md` and `docs/roadmap.md` for mitigation plans.
