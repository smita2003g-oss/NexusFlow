# AI assistance and provenance disclosure

**Generated:** 2026-10-30 in a ChatGPT session as an initial Rust implementation for a user's project request.

**AI contribution estimate:** The initial source code, tests, sample workflows, deployment configuration, CI files and prose documentation in this package were overwhelmingly generated with AI assistance (approximately **95–100% of initial authored content**). Human review, editing, debugging, running compiler/tests, security validation and sustained human development are still required.

**What the initial local Git history means:** The commits were created during this session as real local git operations. They are not backdated, are not pretending to be original team contributions, and are not a substitute for independently reviewed pull requests created on GitHub over months or years.

**No claims made:**

- The code is **not** represented as predominantly human-written.
- There is **no** verified external company/client ownership or exclusive license.
- We cannot certify that no AI provider, data supplier or other entity has received or could receive this text or similar code. This artifact was created in ChatGPT, and confidentiality/retention depends on applicable service terms and account settings.
- No GitHub-hosted history, issue, pull request, maintainer tenure, or external team was examined or verified in this session.
- No 100,000-line threshold, production readiness or successful compilation is claimed.

**License in this package:** MIT, as an intended open-source starter license. This is not a legal opinion about copyright protection, source provenance, or compliance with third-party submission criteria. Before any provenance-sensitive submission, verify chain of title, contributor agreements, AI disclosures, host access, license rights and actual human development record with the appropriate responsible people.

**For genuine long-term eligibility:** Start with a real GitHub repository, make verifiable human-authored enhancements, write meaningful tests and docs, accept genuine PR reviews, and record AI use per change. Measure source LOC without generated dependencies, vendored files, blank lines or padding. Do not inflate line counts or forge history to satisfy a gate.
